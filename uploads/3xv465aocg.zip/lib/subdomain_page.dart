import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class SubdomainPage extends StatefulWidget {
  const SubdomainPage({super.key});

  @override
  State<SubdomainPage> createState() => _SubdomainPageState();
}

class _SubdomainPageState extends State<SubdomainPage> {
  final TextEditingController _controller = TextEditingController(text: "google.com");

  bool isLoading = false;
  List<Map<String, dynamic>> subdomains = [];

  // Warna merah yang digunakan
  static const primaryRed = Color(0xFFEF4444);
  static const accentRed = Color(0xFFDC2626);
  static const lightRed = Color(0xFFFCA5A5);
  static const darkBg = Color(0xFF0A0A0A);
  static const cardBg = Color(0xFF1A1A1A);
  static const inputBg = Color(0xFF2A2A2A);

  Future<void> fetchSubdomains() async {
    final domain = _controller.text.trim();
    if (domain.isEmpty) return;

    setState(() {
      isLoading = true;
      subdomains.clear();
    });

    try {
      final uri = Uri.parse(
          "https://api.siputzx.my.id/api/tools/subdomains?domain=$domain");
      final res = await http.get(uri);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);

        if (data["data"] is List) {
          final List subs = data["data"];

          setState(() {
            subdomains = subs
                .map((s) => {
                      "sub": s,
                      "status": "⏳ Checking...",
                      "statusColor": Colors.orange,
                      "title": "Loading...",
                      "loading": true,
                    })
                .toList();
          });

          for (int i = 0; i < subs.length; i++) {
            checkSubdomain(subs[i], i);
          }
        }
      }
    } catch (e) {
      debugPrint("Error fetch: $e");
    }

    setState(() {
      isLoading = false;
    });
  }

  Future<void> checkSubdomain(String sub, int index) async {
    String status = "❌ Inactive";
    Color statusColor = accentRed;
    String title = "N/A";

    for (var scheme in ["https://", "http://"]) {
      final url = "$scheme$sub";
      try {
        final res = await http
            .get(Uri.parse(url))
            .timeout(const Duration(seconds: 5));

        status = "✅ Active (${res.statusCode})";
        statusColor = primaryRed;
        
        final regex = RegExp(r"<title>(.*?)</title>",
            caseSensitive: false, dotAll: true);
        final match = regex.firstMatch(res.body);
        if (match != null) {
          title = match.group(1)!.trim();
        }
        break;
      } catch (_) {}
    }

    setState(() {
      subdomains[index]["status"] = status;
      subdomains[index]["statusColor"] = statusColor;
      subdomains[index]["title"] = title;
      subdomains[index]["loading"] = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "Subdomain Finder",
          style: TextStyle(
            color: primaryRed,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
        iconTheme: const IconThemeData(color: primaryRed),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: primaryRed.withOpacity(0.3)),
              ),
              child: TextField(
                controller: _controller,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  labelText: "Enter Domain",
                  labelStyle: TextStyle(color: primaryRed.withOpacity(0.7)),
                  filled: true,
                  fillColor: inputBg,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(color: primaryRed.withOpacity(0.3)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: primaryRed),
                  ),
                  prefixIcon: Icon(Icons.public, color: primaryRed),
                ),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              icon: const Icon(Icons.search),
              label: const Text("Find Subdomains"),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryRed,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
                shadowColor: primaryRed.withOpacity(0.5),
              ),
              onPressed: fetchSubdomains,
            ),
            const SizedBox(height: 20),
            Expanded(
              child: isLoading
                  ? const Center(
                      child: CircularProgressIndicator(
                        color: primaryRed,
                      ),
                    )
                  : subdomains.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.search_off, color: Colors.white24, size: 64),
                              const SizedBox(height: 16),
                              const Text(
                                "No subdomains found.",
                                style: TextStyle(color: Colors.white70),
                              ),
                              Text(
                                "Try another domain",
                                style: TextStyle(color: lightRed, fontSize: 12),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: subdomains.length,
                          itemBuilder: (context, index) {
                            final sub = subdomains[index];
                            return Container(
                              margin: const EdgeInsets.symmetric(vertical: 6),
                              decoration: BoxDecoration(
                                color: cardBg,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: primaryRed.withOpacity(0.2),
                                ),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 16,
                                  vertical: 8,
                                ),
                                leading: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: primaryRed.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(
                                    Icons.dns,
                                    color: primaryRed,
                                    size: 20,
                                  ),
                                ),
                                title: Text(
                                  sub["sub"],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 4),
                                    sub["loading"] == true
                                        ? Row(
                                            children: [
                                              SizedBox(
                                                width: 14,
                                                height: 14,
                                                child: CircularProgressIndicator(
                                                  strokeWidth: 2,
                                                  color: primaryRed,
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Text(
                                                "Checking...",
                                                style: TextStyle(
                                                  color: primaryRed,
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          )
                                        : Row(
                                            children: [
                                              Icon(
                                                sub["status"]
                                                        .contains("Active")
                                                    ? Icons.check_circle
                                                    : Icons.cancel,
                                                color: sub["statusColor"],
                                                size: 14,
                                              ),
                                              const SizedBox(width: 4),
                                              Text(
                                                "Status: ${sub["status"]}",
                                                style: TextStyle(
                                                  color: sub["statusColor"],
                                                  fontSize: 12,
                                                ),
                                              ),
                                            ],
                                          ),
                                    const SizedBox(height: 4),
                                    Text(
                                      "Title: ${sub["title"]}",
                                      style: const TextStyle(
                                        color: Colors.white54,
                                        fontSize: 11,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                                trailing: sub["loading"] != true &&
                                        sub["status"].contains("Active")
                                    ? IconButton(
                                        icon: Icon(Icons.open_in_browser,
                                            color: primaryRed, size: 20),
                                        onPressed: () {
                                          // Buka URL di browser
                                        },
                                      )
                                    : null,
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}