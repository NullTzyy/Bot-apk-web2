// BOT TELE
module.exports = {
  BOT_TOKEN: "8943383657:AAES8tuNv6_Od277q_H9QDRUYhDyDLcCST0", // Token bot Telegram
  OWNER_ID: "6311125849", // ID pemilik bot
  allowedGroupIds: [--5207136499], // ID grup yang diizinkan
};