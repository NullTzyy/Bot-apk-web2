// nik_check_page.dart

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class NIKCheckPage extends StatefulWidget {
  final String sessionKey;

  const NIKCheckPage({super.key, required this.sessionKey});

  @override
  State<NIKCheckPage> createState() => _NIKCheckPageState();
}

class _NIKCheckPageState extends State<NIKCheckPage> {
  final TextEditingController _nikController = TextEditingController();
  Map<String, dynamic>? _nikData;
  bool _isLoading = false;

  // Premium Red Color Palette
  static const Color primaryRed = Color(0xFFE53935);      // Vibrant Red
  static const Color darkRed = Color(0xFFC62828);         // Deep Dark Red
  static const Color lightRed = Color(0xFFEF5350);        // Soft Light Red
  static const Color accentRed = Color(0xFFFF5252);       // Bright Accent Red
  static const Color crimsonRed = Color(0xFFD32F2F);      // Crimson Touch
  static const Color roseRed = Color(0xFFFF6B6B);         // Rose Red
  static const Color surfaceColor = Color(0xFF1E1E1E);

  Future<void> _checkNIK() async {
    if (_nikController.text.isEmpty) return;
    setState(() {
      _isLoading = true;
      _nikData = null;
    });
    try {
      final response = await http.get(Uri.parse('https://ppl.nullxteam.fun/api/tools/nik-check?key=${widget.sessionKey}&nik=${_nikController.text}'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          setState(() {
            _nikData = data;
          });
        } else {
          _showSnackBar('Invalid NIK or server error', isError: true);
        }
      } else {
        _showSnackBar('Failed to connect to NIK service', isError: true);
      }
    } catch (e) {
      _showSnackBar('Error: ${e.toString()}', isError: true);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Row(
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle,
            color: isError ? crimsonRed : primaryRed,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(message)),
        ],
      ),
      backgroundColor: Colors.black.withOpacity(0.95),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: (isError ? crimsonRed : primaryRed).withOpacity(0.3),
          width: 1,
        ),
      ),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: ShaderMask(
          shaderCallback: (bounds) => LinearGradient(
            colors: [primaryRed, lightRed],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
          child: const Text(
            'NIK Check',
            style: TextStyle(
              color: Colors.white,
              fontFamily: 'Orbitron',
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ),
        centerTitle: true,
        iconTheme: const IconThemeData(color: primaryRed),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.3),
            border: Border(
              bottom: BorderSide(color: primaryRed.withOpacity(0.2), width: 1),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildInputCard(),
            const SizedBox(height: 24),
            if (_nikData != null) _buildNIKResult(),
          ],
        ),
      ),
    );
  }

  Widget _buildInputCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.05),
            Colors.white.withOpacity(0.02),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: primaryRed.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.05),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: primaryRed.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: primaryRed.withOpacity(0.2)),
                ),
                child: const Icon(Icons.credit_card, color: primaryRed, size: 24),
              ),
              const SizedBox(width: 12),
              Text(
                'Enter NIK Number',
                style: TextStyle(
                  color: primaryRed,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          _buildModernTextField(
            controller: _nikController,
            hint: 'Enter 16-digit NIK number',
            icon: Icons.numbers,
            keyboardType: TextInputType.number,
            maxLength: 16,
          ),
          const SizedBox(height: 20),
          _buildCheckButton(),
        ],
      ),
    );
  }

  Widget _buildModernTextField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    TextInputType keyboardType = TextInputType.text,
    int? maxLength,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.05),
            blurRadius: 8,
            spreadRadius: 1,
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        style: const TextStyle(color: Colors.white, fontSize: 16),
        cursorColor: primaryRed,
        keyboardType: keyboardType,
        maxLength: maxLength,
        decoration: InputDecoration(
          prefixIcon: Container(
            margin: const EdgeInsets.all(10),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: primaryRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: primaryRed, size: 20),
          ),
          hintText: hint,
          hintStyle: TextStyle(
            color: primaryRed.withOpacity(0.5),
            fontFamily: 'ShareTechMono',
            fontSize: 14,
          ),
          counterText: '',
          filled: true,
          fillColor: Colors.white.withOpacity(0.03),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: primaryRed.withOpacity(0.2), width: 1),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentRed, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        ),
      ),
    );
  }

  Widget _buildCheckButton() {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      height: 50,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        gradient: LinearGradient(
          colors: [primaryRed, lightRed],
        ),
        boxShadow: [
          BoxShadow(
            color: primaryRed.withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ElevatedButton(
        onPressed: _isLoading ? null : _checkNIK,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: _isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
            : const Text(
                'CHECK NIK',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
      ),
    );
  }

  Widget _buildNIKResult() {
    final data = _nikData!['data'] as Map<String, dynamic>;
    final nikData = data['data'] as Map<String, dynamic>;
    final metadata = data['metadata'] as Map<String, dynamic>;

    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white.withOpacity(0.05),
              Colors.white.withOpacity(0.02),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: primaryRed.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: primaryRed.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: primaryRed.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: primaryRed.withOpacity(0.3)),
                  ),
                  child: const Icon(Icons.verified_user, color: primaryRed, size: 28),
                ),
                const SizedBox(width: 12),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'NIK Information',
                      style: TextStyle(
                        color: primaryRed,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                    Container(
                      width: 50,
                      height: 3,
                      decoration: BoxDecoration(
                        color: primaryRed,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 20),
            _buildInfoSection('Personal Information', [
              ('NIK', nikData['nik'] ?? 'N/A', Icons.numbers),
              ('Name', nikData['nama'] ?? 'N/A', Icons.person),
              ('Gender', nikData['kelamin'] ?? 'N/A', Icons.wc),
              ('Birth Date', nikData['tempat_lahir'] ?? 'N/A', Icons.cake),
              ('Age', nikData['usia'] ?? 'N/A', Icons.timer),
            ]),
            const SizedBox(height: 16),
            _buildInfoSection('Location Information', [
              ('Province', nikData['provinsi'] ?? 'N/A', Icons.location_city),
              ('Regency', nikData['kabupaten'] ?? 'N/A', Icons.location_on),
              ('District', nikData['kecamatan'] ?? 'N/A', Icons.map),
              ('Sub-district', nikData['kelurahan'] ?? 'N/A', Icons.my_location),
              ('Address', nikData['alamat'] ?? 'N/A', Icons.home),
            ]),
            const SizedBox(height: 16),
            _buildInfoSection('Additional Information', [
              ('Zodiac', nikData['zodiak'] ?? 'N/A', Icons.star),
              ('Next Birthday', nikData['ultah_mendatang'] ?? 'N/A', Icons.cake),
              ('Pasaran', nikData['pasaran'] ?? 'N/A', Icons.calendar_today),
            ]),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: primaryRed.withOpacity(0.2)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info_outline, color: primaryRed, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        'Metadata',
                        style: TextStyle(
                          color: primaryRed,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  _buildMetaRow('Search Method', metadata['metode_pencarian'] ?? 'N/A'),
                  _buildMetaRow('Area Code', metadata['kode_wilayah'] ?? 'N/A'),
                  _buildMetaRow('Sequence Number', metadata['nomor_urut'] ?? 'N/A'),
                  _buildMetaRow('Age Category', metadata['kategori_usia'] ?? 'N/A'),
                  _buildMetaRow('Area Type', metadata['jenis_wilayah'] ?? 'N/A'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoSection(String title, List<(String, String, IconData)> items) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              color: lightRed,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              fontFamily: 'Orbitron',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          ...items.map((item) => _buildInfoRow(item.$1, item.$2, item.$3)),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 110,
            child: Row(
              children: [
                Icon(icon, color: primaryRed.withOpacity(0.6), size: 16),
                const SizedBox(width: 6),
                Text(
                  '$label:',
                  style: TextStyle(
                    color: primaryRed.withOpacity(0.7),
                    fontSize: 13,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.05),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                value,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetaRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text(
            '$label:',
            style: TextStyle(
              color: primaryRed.withOpacity(0.6),
              fontSize: 12,
              fontFamily: 'ShareTechMono',
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}