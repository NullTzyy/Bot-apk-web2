module.exports = {
  tokens: "8859662119:AAHxj6Md97FGtH96JXSNle-rLkzAtwzsaAE",  // Masukin Bot token kamu
  owners: "6311125849", // Masukin ID Telegram kamu
  port: "2306", // Masukin Port panel kamu 
  ipvps: "http://do.mbbstore.my.id:2306" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/