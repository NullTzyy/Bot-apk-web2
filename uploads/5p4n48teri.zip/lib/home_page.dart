import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

class AttackPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<AttackPage> createState() => _AttackPageState();
}

class _AttackPageState extends State<AttackPage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  static const String baseUrl = "http://manipulator.panel.serverku.space:2026";

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _glowController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _glowAnimation;

  // Video controllers
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // State variables
  String selectedBugId = "";
  bool _isSending = false;
  bool _isSuccess = false;
  int _activeStep = 0;
  
  // Sender type: "private" or "global"
  String _senderType = "private";

  // COLOR THEME: Abu-abu Menyala (Bright Gray / Silver Glow)
  final Color _themeColor = const Color(0xFFE0E0E0);
  final Color _cardColor = const Color(0xFF1E232D); // Dark slate from image
  final Color _inputColor = const Color(0xFF151921); // Darker inner background

  // Check if user can use global sender
  bool get canUseGlobalSender {
    final allowedRoles = ["founder", "vip", "owner", "high admin", "moderator"];
    return allowedRoles.contains(widget.role.toLowerCase());
  }

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
    _setDefaultBug();
    _startAnimations();
    
    // Set default sender type based on role
    if (!canUseGlobalSender) {
      _senderType = "private";
    }
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );

    // FIXED 1: Pisahkan assignment dan pemanggilan repeat() untuk bypass TickerFuture error
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _glowController.repeat(reverse: true);

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );
  }

  void _startAnimations() {
    _fadeController.forward();
    Future.delayed(const Duration(milliseconds: 200), () {
      _slideController.forward();
    });
  }

  void _setDefaultBug() {
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _videoController.setLooping(true);
            _videoController.play();
            _videoController.setVolume(0);
          }
        }).catchError((error) {
          print('Video initialization error: $error');
          if (mounted) {
            setState(() {
              _videoError = true;
            });
          }
        });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
      _activeStep = 1;
    });

    _buttonController.forward().then((_) {
      _buttonController.reverse();
    });

    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      setState(() {
        _isSending = false;
        _activeStep = 0;
      });
      return;
    }

    try {
      // Add senderType parameter to API call
      final res = await http.get(Uri.parse("$baseUrl/api/whatsapp/sendBug?key=$key&target=$target&bug=$selectedBugId&senderType=$_senderType"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["senderOn"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Sender Kosong, Hubungi Seller.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        setState(() {
          _activeStep = 2;
          _isSuccess = true;
        });
        _showSuccessPopup(target);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
        if (!_isSuccess) _activeStep = 0;
      });
    }
  }

  void _showSuccessPopup(String target) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => SuccessVideoDialog(
        target: target,
        senderType: _senderType,
        onDismiss: () {
          Navigator.of(context).pop();
          setState(() {
            _isSuccess = false;
            _activeStep = 0;
          });
        },
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.9),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _themeColor.withOpacity(0.3), width: 1),
        ),
        title: Text(title, style: const TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _themeColor)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF8BA68D),
      body: Stack(
        children: [
          // Animated background (Video)
          _buildAnimatedBackground(),

          // Dark Overlay for readability
          Container(
            color: Colors.black.withOpacity(0.5),
          ),

          // Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
                child: FadeTransition(
                  opacity: _fadeAnimation,
                  child: SlideTransition(
                    position: _slideAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        // User info header
                        _buildUserInfoHeader(),
                        const SizedBox(height: 30),

                        // MAIN HEADER LIKE IMAGE
                        _buildMainHeader(),
                        const SizedBox(height: 30),

                        // Main content cards
                        _buildTargetInputCard(),
                        const SizedBox(height: 16),

                        _buildPayloadTypeCard(),
                        const SizedBox(height: 16),

                        // Sender Type Selection Card
                        _buildSenderTypeCard(),
                        const SizedBox(height: 30),

                        _buildSendButton(),
                        const SizedBox(height: 30),

                        // Bottom Status Indicators
                        _buildBottomIndicators(),
                        
                        const SizedBox(height: 20),
                        // Footer info
                        _buildFooterInfo(),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainHeader() {
    return Column(
      children: [
        AnimatedBuilder(
          animation: _glowController,
          builder: (context, child) {
            return Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: _themeColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _themeColor.withOpacity(0.5 * _glowAnimation.value),
                    blurRadius: 20,
                    spreadRadius: 2,
                  )
                ]
              ),
              child: const Center(
                child: Icon(
                  FontAwesomeIcons.bolt,
                  color: Colors.black,
                  size: 45,
                ),
              ),
            );
          }
        ),
        const SizedBox(height: 16),
        const Text(
          "BASIC BUG",
          style: TextStyle(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
            fontFamily: 'Orbitron',
            shadows: [
              Shadow(color: Colors.black, blurRadius: 10, offset: Offset(0, 2))
            ]
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            color: _themeColor,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: _themeColor.withOpacity(0.3),
                blurRadius: 10,
                spreadRadius: 1,
              )
            ]
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(FontAwesomeIcons.bolt, color: Colors.black, size: 14),
              SizedBox(width: 8),
              Text(
                "NOCURE APP",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget _buildAnimatedBackground() {
    return _videoInitialized && !_videoError
        ? SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _videoController.value.size.width,
          height: _videoController.value.size.height,
          child: VideoPlayer(_videoController),
        ),
      ),
    )
        : Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0A)
      ),
    );
  }

  Widget _buildUserInfoHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.4),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            backgroundColor: _themeColor.withOpacity(0.2),
            radius: 14,
            child: Icon(FontAwesomeIcons.userSecret, color: _themeColor, size: 12),
          ),
          const SizedBox(width: 8),
          Text(
            widget.username,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(color: _themeColor.withOpacity(0.8), borderRadius: BorderRadius.circular(10)),
            child: Text(
              widget.role.toUpperCase(),
              style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTargetInputCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: _themeColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(FontAwesomeIcons.bullseye, color: Colors.black, size: 18),
              ),
              const SizedBox(width: 16),
              const Text(
                "Target Number",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            decoration: BoxDecoration(
              color: _inputColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: TextField(
              controller: targetController,
              style: const TextStyle(color: Colors.white, fontSize: 16, letterSpacing: 1.5),
              cursorColor: _themeColor,
              decoration: InputDecoration(
                hintText: "+62812345678",
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.2)),
                border: InputBorder.none,
                prefixIcon: Icon(FontAwesomeIcons.phoneAlt, color: _themeColor, size: 16),
                contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPayloadTypeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: _themeColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(FontAwesomeIcons.bug, color: Colors.black, size: 18),
              ),
              const SizedBox(width: 16),
              const Text(
                "Select Bug",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            decoration: BoxDecoration(
              color: _inputColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                dropdownColor: _cardColor,
                value: selectedBugId.isNotEmpty ? selectedBugId : null,
                isExpanded: true,
                icon: Icon(Icons.keyboard_arrow_down, color: _themeColor),
                style: const TextStyle(color: Colors.white, fontSize: 15, letterSpacing: 1),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Text(
                      bug['bug_name'].toString().toUpperCase(),
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedBugId = value!;
                  });
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderTypeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardColor,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 15, offset: const Offset(0, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: _themeColor,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(FontAwesomeIcons.server, color: Colors.black, size: 18),
              ),
              const SizedBox(width: 16),
              const Text(
                "Sender Type",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (canUseGlobalSender) {
                      setState(() => _senderType = "global");
                    } else {
                      _showAlert("Access Denied", "Global sender hanya untuk role: Founder, VIP, Owner, High Admin, Moderator");
                    }
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _senderType == "global"
                          ? _themeColor.withOpacity(0.3)
                          : Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _senderType == "global"
                            ? _themeColor
                            : Colors.white.withOpacity(0.1),
                        width: _senderType == "global" ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          FontAwesomeIcons.globe,
                          color: _senderType == "global"
                              ? _themeColor
                              : Colors.white54,
                          size: 24,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Global",
                          style: TextStyle(
                            color: _senderType == "global" ? _themeColor : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "High Priority",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 10,
                          ),
                        ),
                        if (!canUseGlobalSender && _senderType != "global")
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Icon(
                              FontAwesomeIcons.lock,
                              color: Colors.red.withOpacity(0.5),
                              size: 12,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _senderType = "private"),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _senderType == "private"
                          ? _themeColor.withOpacity(0.3)
                          : Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: _senderType == "private"
                            ? _themeColor
                            : Colors.white.withOpacity(0.1),
                        width: _senderType == "private" ? 2 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          FontAwesomeIcons.user,
                          color: _senderType == "private"
                              ? _themeColor
                              : Colors.white54,
                          size: 24,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Private",
                          style: TextStyle(
                            color: _senderType == "private" ? _themeColor : Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "All Roles",
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.4),
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: _senderType == "global" && canUseGlobalSender
                  ? _themeColor.withOpacity(0.1)
                  : Colors.white.withOpacity(0.05),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(
                  _senderType == "global" ? FontAwesomeIcons.bolt : FontAwesomeIcons.shieldAlt,
                  color: _themeColor.withOpacity(0.6),
                  size: 12,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _senderType == "global"
                        ? "Global sender: High speed attack dengan prioritas tinggi"
                        : "Private sender: Standard attack untuk semua pengguna",
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.5),
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Container(
            width: double.infinity,
            height: 60,
            decoration: BoxDecoration(
              color: _themeColor,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: _themeColor.withOpacity(0.4),
                  blurRadius: 20,
                  spreadRadius: 2,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: _isSending ? null : _sendBug,
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _isSending
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(color: Colors.black, strokeWidth: 3),
                            )
                          : Icon(
                              _senderType == "global" ? FontAwesomeIcons.rocket : FontAwesomeIcons.paperPlane,
                              color: Colors.black,
                              size: 20,
                            ),
                      const SizedBox(width: 12),
                      Text(
                        _isSending 
                            ? "SENDING..." 
                            : (_senderType == "global" ? "GLOBAL ATTACK" : "SEND ATTACK"),
                        style: const TextStyle(
                          fontSize: 18,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                          color: Colors.black,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomIndicators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildIconStatusItem(FontAwesomeIcons.tachometerAlt, "Fast", "Execution"),
        _buildIconStatusItem(FontAwesomeIcons.shieldAlt, "Simple", "Setup"),
        _buildIconStatusItem(FontAwesomeIcons.chartLine, "Reliable", "Results"),
      ],
    );
  }

  Widget _buildIconStatusItem(IconData icon, String line1, String line2) {
    return Container(
      width: 90,
      height: 100,
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: _themeColor, size: 28),
          const SizedBox(height: 12),
          Text(
            line1,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
          ),
          const SizedBox(height: 2),
          Text(
            line2,
            style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 10),
          ),
        ],
      ),
    );
  }

  Widget _buildFooterInfo() {
    return Center(
      child: Text(
        "EXP: ${widget.expiredDate} | SENDER: ${_senderType.toUpperCase()} | SYSTEM SECURED",
        style: TextStyle(
          color: Colors.white.withOpacity(0.3),
          fontSize: 10,
          fontFamily: 'Orbitron',
          letterSpacing: 2,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _fadeController.dispose();
    _slideController.dispose();
    _glowController.dispose();
    _videoController.dispose();
    targetController.dispose();
    super.dispose();
  }
}

// Custom success dialog with video
class SuccessVideoDialog extends StatefulWidget {
  final String target;
  final String senderType;
  final VoidCallback onDismiss;

  const SuccessVideoDialog({
    super.key,
    required this.target,
    required this.senderType,
    required this.onDismiss,
  });

  @override
  State<SuccessVideoDialog> createState() => _SuccessVideoDialogState();
}

class _SuccessVideoDialogState extends State<SuccessVideoDialog> with TickerProviderStateMixin {
  late VideoPlayerController _successVideoController;
  late AnimationController _fadeController;
  late AnimationController _scaleController;
  late AnimationController _glowController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _glowAnimation;
  bool _showSuccessInfo = false;
  bool _videoError = false;
  bool _videoInitialized = false;

  final Color _themeColor = const Color(0xFFE0E0E0);

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    // FIXED 2: Pisahkan assignment dan pemanggilan repeat() untuk dialog ini
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _glowController.repeat(reverse: true);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _scaleController, curve: Curves.elasticOut),
    );

    _glowAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _glowController, curve: Curves.easeInOut),
    );

    _initializeSuccessVideo();
  }

  void _initializeSuccessVideo() {
    try {
      _successVideoController = VideoPlayerController.asset('assets/videos/splash.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() {
              _videoInitialized = true;
            });
            _successVideoController.play();
            _successVideoController.addListener(() {
              if (_successVideoController.value.position >= _successVideoController.value.duration) {
                _showSuccessMessage();
              }
            });
          }
        }).catchError((error) {
          if (mounted) {
            setState(() {
              _videoError = true;
            });
            Future.delayed(const Duration(milliseconds: 500), () {
              _showSuccessMessage();
            });
          }
        });
    } catch (e) {
      if (mounted) {
        setState(() {
          _videoError = true;
        });
        Future.delayed(const Duration(milliseconds: 500), () {
          _showSuccessMessage();
        });
      }
    }
  }

  void _showSuccessMessage() {
    if (mounted) {
      setState(() {
        _showSuccessInfo = true;
      });
      _fadeController.forward();
      _scaleController.forward();
    }
  }

  @override
  void dispose() {
    _successVideoController.dispose();
    _fadeController.dispose();
    _scaleController.dispose();
    _glowController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final dialogWidth = screenSize.width * 0.9;
    final dialogHeight = screenSize.height * 0.45;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: dialogWidth,
          maxHeight: dialogHeight,
        ),
        child: Container(
          width: dialogWidth,
          height: dialogHeight,
          decoration: BoxDecoration(
            color: const Color(0xFF1E232D),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _themeColor,
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: _themeColor.withOpacity(0.3),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Stack(
            children: [
              if (!_showSuccessInfo)
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: _videoInitialized && !_videoError
                      ? SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _successVideoController.value.size.width,
                        height: _successVideoController.value.size.height,
                        child: VideoPlayer(_successVideoController),
                      ),
                    ),
                  )
                      : Container(
                    width: double.infinity,
                    height: double.infinity,
                    color: Colors.black,
                  ),
                ),

              if (_showSuccessInfo)
                FadeTransition(
                  opacity: _fadeAnimation,
                  child: ScaleTransition(
                    scale: _scaleAnimation,
                    child: Container(
                      width: double.infinity,
                      height: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color(0xFF1E232D),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          AnimatedBuilder(
                            animation: _glowController,
                            builder: (context, child) {
                              return Container(
                                padding: const EdgeInsets.all(20),
                                decoration: BoxDecoration(
                                  color: _themeColor,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: _themeColor.withOpacity(0.5 * _glowAnimation.value),
                                      blurRadius: 20,
                                      spreadRadius: 5,
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  widget.senderType == "global" 
                                      ? FontAwesomeIcons.rocket 
                                      : FontAwesomeIcons.skull,
                                  color: Colors.black,
                                  size: 40,
                                ),
                              );
                            },
                          ),
                          const SizedBox(height: 24),
                          Text(
                            widget.senderType == "global" ? "GLOBAL ATTACK!" : "ATTACK DELIVERED",
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Target: ${widget.target}\nSender: ${widget.senderType.toUpperCase()}\nStatus: SUCCESS",
                            style: TextStyle(
                              color: _themeColor,
                              fontSize: 14,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 1,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 30),
                          ElevatedButton(
                            onPressed: widget.onDismiss,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _themeColor,
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: const Text(
                              "CLOSE",
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}