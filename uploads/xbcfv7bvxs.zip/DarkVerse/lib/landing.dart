import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> fadeAnimation;
  late Animation<Offset> slideAnimation;

// --- TEMA ELEGAN GELAP & MERAH TUA ---
  final Color darkBg = const Color(0xFF0F0A0D);     // Hitam dengan hint merah gelap
  final Color redPrimary = const Color(0xFF7A0C14); // Merah tua elegan (wine red)
  final Color redAccent = const Color(0xFFB11226);  // Merah bold premium
  final Color redGlow = const Color(0xFFE63946);    // Merah glow halus (tidak terlalu terang)

  @override
  void initState() {
    super.initState();

    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 1));

    fadeAnimation =
        Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    ));

    slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
            .animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOutCubic,
    ));

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      body: Stack(
        children: [

          // 🔴 BACKGROUND RED GLOW
          Positioned(
            top: -120,
            left: -80,
            child: _glowCircle(320, redPrimary.withOpacity(0.4)),
          ),
          Positioned(
            bottom: -150,
            right: -100,
            child: _glowCircle(360, redAccent.withOpacity(0.4)),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: fadeAnimation,
              child: SlideTransition(
                position: slideAnimation,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: Column(
                    children: [

                      const SizedBox(height: 60),

                      // HERO IMAGE
                      SizedBox(
                        height: 320,
                        child: Image.asset(
                          "assets/images/reze.png",
                          fit: BoxFit.contain,
                        ),
                      ),

                      const SizedBox(height: 30),

                      // TITLE
                      ShaderMask(
                        shaderCallback: (bounds) => LinearGradient(
                          colors: [redAccent, Colors.white],
                        ).createShader(bounds),
                        child: const Text(
                          "RONOVA",
                          style: TextStyle(
                            fontSize: 38,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                            color: Colors.white,
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      const Text(
                        "Premium Access Platform\nSecure • Private • Exclusive",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 14,
                          height: 1.6,
                        ),
                      ),

                      const SizedBox(height: 40),

                      // 🔥 GLASS OVERGLAZE PANEL
                      ClipRRect(
                        borderRadius: BorderRadius.circular(26),
                        child: BackdropFilter(
                          filter:
                              ImageFilter.blur(sigmaX: 30, sigmaY: 30),
                          child: Container(
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.05),
                              borderRadius: BorderRadius.circular(26),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.12)),
                            ),
                            child: Column(
                              children: [

                                _primaryButton(),

                                const SizedBox(height: 16),

                                _secondaryButton(),

                                const SizedBox(height: 24),

                                Row(
                                  children: [
                                    Expanded(
                                      child: _contactButton(
                                        FontAwesomeIcons.telegram,
                                        "Telegram",
                                        "https://t.me/fantzy_reals13",
                                        const Color(0xFF0088cc),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: _contactButton(
                                        FontAwesomeIcons.whatsapp,
                                        "WhatsApp",
                                        "https://wa.me/6283165770011",
                                        const Color(0xFF25D366),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),

                      const SizedBox(height: 40),

                      const Text(
                        "© 2026 Ronova. All Rights Reserved.",
                        style: TextStyle(
                            color: Colors.white38, fontSize: 12),
                      ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 🔴 Glow Circle
  Widget _glowCircle(double size, Color color) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          colors: [color, Colors.transparent],
        ),
      ),
    );
  }

  // 🔥 PRIMARY BUTTON
  Widget _primaryButton() {
    return Container(
      width: double.infinity,
      height: 55,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [redPrimary, redAccent],
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: redGlow.withOpacity(0.6),
            blurRadius: 25,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: () {
          Navigator.pushNamed(context, "/login");
        },
        child: const Text(
          "Sign In",
          style: TextStyle(
              fontWeight: FontWeight.bold, fontSize: 16),
        ),
      ),
    );
  }

  Widget _secondaryButton() {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(double.infinity, 55),
        side: BorderSide(color: redAccent.withOpacity(0.6)),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      onPressed: () =>
          _openUrl("https://t.me/InfoChDarkness/292"),
      child: const Text(
        "Buy Access",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _contactButton(
      IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _openUrl(url),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(14),
          border:
              Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white70,
                fontWeight: FontWeight.w600,
              ),
            )
          ],
        ),
      ),
    );
  }
}