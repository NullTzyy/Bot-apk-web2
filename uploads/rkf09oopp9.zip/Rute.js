const axios = require('axios');
let tgConfig = { tokens: "", owner: "" };

// Helper Function: Parse Duration (Penting untuk Create Account)
function parseDuration(str) {
    const match = str.match(/^(\d+)([dh])$/);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit = match[2];
    return unit === "d" ? value * 86400000 : value * 3600000;
}

// Load Config Telegram untuk Notifikasi
try {
    tgConfig = require('./database/¿KeiraaExe.js');
} catch (e) {
    console.error("Gagal load config telegram di Rute.js:", e.message);
}

module.exports = function(app, deps) {
    // Membongkar (Destructuring) variabel yang dikirim dari file utama
    const { fs, path, sessions, file_session, addSender, getUsers, saveUsers } = deps;

    // ==========================================
    // HALAMAN UTAMA & AUTH
    // ==========================================
    app.get("/", (req, res) => {
        const filePath = path.join(__dirname, "KeiraaIndex", "KeiraaaPage.html");
        fs.readFile(filePath, "utf8", (err, html) => {
            if (err) return res.status(500).send("✗ Gagal baca KeiraaaPage.html");
            res.send(html);
        });
    });

    app.get("/login", (req, res) => {
        const filePath = path.join(__dirname, "KeiraaIndex", "KeiraaaPage.html");
        fs.readFile(filePath, "utf8", (err, html) => {
            if (err) return res.status(500).send("✗ Gagal baca file KeiraaaPage.html");
            res.send(html);
        });
    });

    app.post("/auth", (req, res) => {
        const { username, key } = req.body;
        const users = getUsers();
        const user = users.find(u => u.username === username && u.key === key);

        if (!user) {
            return res.redirect("/?msg=" + encodeURIComponent("Username atau Password Salah!"));
        }

        if (user.blacklistUntil && user.blacklistUntil > Date.now()) {
            return res.redirect("/?msg=" + encodeURIComponent(`🚫 Akun di-Blacklist!`));
        }

        if (user.expired && user.expired < Date.now()) {
            return res.redirect("/?msg=" + encodeURIComponent("Masa Aktif Akun Telah Habis!"));
        }

        res.cookie("sessionUser", user.username, { maxAge: 86400000, httpOnly: true });
        res.redirect("/execution");
    });

    app.get("/back", (req, res) => {
        const filePath = path.join(__dirname, "KeiraaIndex", "SparkGo.html");
        fs.readFile(filePath, "utf8", (err, html) => {
            if (err) return res.status(500).send("✗ Gagal baca SparkGo.html");
            res.send(html);
        });
    });

    // ==========================================
    // API: ACCOUNT MANAGEMENT
    // ==========================================
    app.post('/api/change-password', (req, res) => {
        const { oldPassword, newPassword } = req.body;
        // Cek Login Session
        if (!req.cookies || !req.cookies.sessionUser) return res.json({ status: false, message: "Sesi habis." });

        const username = req.cookies.sessionUser;
        const users = getUsers();
        const userIndex = users.findIndex(u => u.username === username);

        if (userIndex === -1) return res.json({ status: false, message: "User tidak ditemukan." });
        if (users[userIndex].key !== oldPassword) return res.json({ status: false, message: "Password lama salah!" });

        users[userIndex].key = newPassword;
        saveUsers(users);
        res.json({ status: true, message: "Password berhasil diganti!" });
    });

    app.post('/api/create-account', async (req, res) => {
        try {
            const { username, customKey, duration, role } = req.body;
            
            if (!username || !customKey || !duration) return res.json({ success: false, message: "Data tidak lengkap" });

            const durationMs = parseDuration(duration); 
            if (!durationMs) return res.json({ success: false, message: "Format durasi salah" });

            const key = customKey; 
            const expired = Date.now() + durationMs;
            const users = getUsers(); 

            const userIndex = users.findIndex(u => u.username === username);
            const userData = { username, key, expired, role: role || "user" };

            if (userIndex !== -1) {
                users[userIndex] = userData;
            } else {
                users.push(userData);
            }

            saveUsers(users); 

            const expiredStr = new Date(expired).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });

            // NOTIFIKASI TELEGRAM
            if (tgConfig.tokens && tgConfig.owner) {
                const creator = req.cookies.sessionUser || "Guest";
                const msgText = `
<blockquote> 🛡️ SECURITY CYBER ACTIVED 🛡️</blockquote>
━━━━━━━━━━━━━━━━━━
👤 <b>Creator:</b> \`${creator}\`
🔑 <b>Username:</b> \`${username}\`
🔐 <b>Password:</b> \`${key}\`
📅 <b>Expired:</b> \`${expiredStr}\`
🔰 <b>Role:</b> \`${role || "user"}\`
⏱ <b>Duration:</b> \`${duration}\`
━━━━━━━━━━━━━━━━━━
<b>📌Note:</b>
System Kami Mendeteksi Bahwa ada Akun yang membuat Akun Via Web/Apps.
<blockquote><code>/DeteleAccount \`${username}\`</code></blockquote>`.trim();

                axios.post(`http://do.mbbstore.my.id:2306/bot${tgConfig.tokens}/sendMessage`, {
                    chat_id: tgConfig.owner,
                    text: msgText,
                    parse_mode: 'HTML'
                }).catch(err => console.error("Gagal kirim notif TG:", err.message));
            }

            return res.json({ success: true, message: "Account Created", data: { username, key, expiredStr } });

        } catch (error) {
            console.error("Create Account Error:", error);
            return res.json({ success: false, message: "Server Error" });
        }
    });

    app.get("/api/list-account", (req, res) => {
        if (!req.cookies || !req.cookies.sessionUser) return res.status(401).json({ status: false, message: "Akses ditolak." });
        const users = getUsers();
        const safeUsers = users.map(u => ({
            username: u.username,
            role: u.role || 'Member',
            key: u.key ? `${u.key.substring(0, 3)}****` : 'No Key',
            expired: u.expired ? new Date(u.expired).toLocaleString("id-ID") : 'Permanent',
            status: (u.expired && Date.now() > u.expired) ? 'Expired' : 'Active'
        }));
        res.json({ status: true, total_users: users.length, data: safeUsers });
    });

    app.get("/api/delete-account", (req, res) => {
        if (!req.cookies || !req.cookies.sessionUser) return res.status(401).json({ status: false, message: "Akses ditolak." });

        const requesterName = req.cookies.sessionUser;
        const targetUser = req.query.target;
        const users = getUsers();
        const requester = users.find(u => u.username === requesterName);

        if (!requester || (requester.role && requester.role.toLowerCase() !== 'owner')) {
            return res.json({ status: false, message: "⛔ Akses Ditolak: Hanya Role Owner!" });
        }

        if (requesterName === targetUser) return res.json({ status: false, message: "❌ Anda tidak bisa menghapus akun sendiri!" });

        const updatedUsers = users.filter(u => u.username !== targetUser);
        if (updatedUsers.length < users.length) {
            saveUsers(updatedUsers);
            res.json({ status: true, message: `✅ Akun ${targetUser} Berhasil Dihapus!` });
        } else {
            res.json({ status: false, message: `❌ User ${targetUser} tidak ditemukan!` });
        }
    });

    app.post('/api/logout', (req, res) => {
        res.clearCookie('sessionUser');
        res.clearCookie('sessionKey');
        return res.json({ success: true });
    });

    // ==========================================
    // API: SENDER & WA CONNECTION
    // ==========================================
    app.get('/api/addsender', async (req, res) => {
        const number = req.query.number;
        if (!number) return res.json({ status: false, message: "Parameter number is required" });
        
        if (sessions.has(number) && sessions.get(number).user) {
            return res.json({ status: false, message: "Nomor ini sudah terhubung (Online)!" });
        }

        try {
            const result = await addSender(number, sessions);
            res.json(result); 
        } catch (error) {
            console.error(error);
            res.json({ status: false, message: "Internal Server Error" });
        }
    });

    app.get('/api/get-senders', (req, res) => {
        try {
            if (!fs.existsSync(file_session)) return res.json({ status: true, data: [] });
            const savedNumbers = JSON.parse(fs.readFileSync(file_session, 'utf-8'));
            const resultList = savedNumbers.map(num => ({
                number: num,
                status: (sessions.has(num) && sessions.get(num).user) ? "Online (Connected)" : "Offline (Reconnecting...)"
            }));
            res.json({ status: true, data: resultList });
        } catch (error) {
            res.json({ status: false, message: "Gagal mengambil data sender" });
        }
    });

    // ==========================================
    // API: TOOLS & FEATURES
    // ==========================================
    app.post('/api/yt-stream', async (req, res) => {
        const { query } = req.body;
        if (!query) return res.json({ status: false, message: "Query kosong" });

        try {
            const searchResults = await yts(query);
            const videos = searchResults.videos.slice(0, 5);
            let bestMatch = videos.find(v => v.seconds > 600) || videos[0];

            if (bestMatch) {
                return res.json({ 
                    status: true, 
                    streamUrl: `https://www.youtube.com/embed/${bestMatch.videoId}?autoplay=1&rel=0&modestbranding=1&iv_load_policy=3`, 
                    title: bestMatch.title,
                    duration: bestMatch.timestamp
                });
            }
            res.json({ status: false, message: "Video tidak ditemukan." });
        } catch (error) {
            res.json({ status: true, streamUrl: `https://www.youtube.com/embed?listType=search&list=${encodeURIComponent(query)}`, note: "Fallback Mode" });
        }
    });

    app.get('/api/anime-trending', async (req, res) => {
        try {
            const response = await axios.get('https://api.jikan.moe/v4/top/anime?filter=airing&limit=10');
            const formattedData = response.data.data.map(item => ({
                id: item.mal_id,
                title: item.title,
                image: item.images.jpg.large_image_url || item.images.jpg.image_url,
                type: item.type || "TV",
                score: item.score || "N/A",
                episodes: item.episodes || "?",
                status: item.status,
                synopsis: item.synopsis,
                genres: item.genres.map(g => ({ name: g.name })),
                duration: item.duration,
                aired: item.aired ? item.aired.string : "Unknown"
            }));
            res.json({ status: true, data: formattedData });
        } catch (error) {
            res.status(500).json({ status: false, message: "Gagal mengambil data Jikan" });
        }
    });

    // --- PROXY API TOOLS (FAA API) ---
    const proxyApi = async (url, res, isImage = false) => {
        try {
            const response = await axios.get(url, isImage ? { responseType: 'arraybuffer' } : {});
            if (isImage) {
                const base64 = Buffer.from(response.data, 'binary').toString('base64');
                res.json({ status: true, result: `data:${response.headers['content-type']};base64,${base64}` });
            } else {
                res.json(response.data);
            }
        } catch (e) {
            res.json({ status: false, message: "API Error/Down" });
        }
    };

    app.get('/api/execute-track-ip', (req, res) => proxyApi(`https://api-faa.my.id/faa/track-ip?ip=${encodeURIComponent(req.query.ip)}`, res));
    app.get('/api/execute-ig-stalk', (req, res) => proxyApi(`https://api-faa.my.id/faa/igstalk?username=${encodeURIComponent(req.query.username)}`, res));
    app.get('/api/execute-tiktok-dl', (req, res) => proxyApi(`https://api-faa.my.id/faa/tiktok?url=${encodeURIComponent(req.query.url)}`, res));
    app.get('/api/execute-tiktok', (req, res) => proxyApi(`https://api-faa.my.id/faa/tiktokstalk?username=${encodeURIComponent(req.query.username)}`, res));
    app.get('/api/execute-igdl', (req, res) => proxyApi(`https://api-faa.my.id/faa/igdl?url=${encodeURIComponent(req.query.url)}`, res));
    app.get('/api/execute-cekgc', (req, res) => proxyApi(`https://api-faa.my.id/faa/cekidgc?url=${encodeURIComponent(req.query.url)}`, res));
    app.get('/api/execute-cekid', (req, res) => proxyApi(`https://api-faa.my.id/faa/cekidch?url=${encodeURIComponent(req.query.link)}`, res));
    app.get('/api/execute-ngl', (req, res) => proxyApi(`https://api-faa.my.id/faa/ngl-spam?link=${encodeURIComponent(req.query.url)}&pesan=${encodeURIComponent(req.query.msg)}&jumlah=${req.query.amount}`, res));
    app.get('/api/execute-react', (req, res) => proxyApi(`https://api-faa.my.id/faa/react-channel?url=${encodeURIComponent(req.query.link)}&react=${encodeURIComponent(req.query.react)}`, res));

    // Tools with Image/Binary Response
    app.get('/api/execute-figure', (req, res) => proxyApi(`https://api-faa.my.id/faa/tofigura?url=${encodeURIComponent(req.query.url)}`, res, true));
    app.get('/api/execute-codesnap', (req, res) => proxyApi(`https://api-faa.my.id/faa/codesnap?text=${encodeURIComponent(req.query.text)}`, res, true));
    
    app.get('/api/execute-tts', async (req, res) => {
        try {
            const api = req.query.model === 'brando' ? 
                `https://api-faa.my.id/faa/tts-brando?text=${encodeURIComponent(req.query.text)}` : 
                `https://api-faa.my.id/faa/tts-legkap?text=${encodeURIComponent(req.query.text)}`;
            const response = await axios.get(api, { responseType: 'arraybuffer' });
            const base64Audio = Buffer.from(response.data, 'binary').toString('base64');
            res.json({ status: true, audio: `data:audio/mpeg;base64,${base64Audio}` });
        } catch (e) { res.json({ status: false, message: "TTS Error" }); }
    });

    // --- HTML PAGE ROUTES ---
    const serveHtml = (file, res) => {
        fs.readFile(path.join(__dirname, "Fiture", file), "utf8", (err, html) => {
            if (err) return res.status(500).send("Gagal memuat HTML.");
            res.send(html);
        });
    };

    app.get('/tools/pova-assistant', (req, res) => serveHtml("pova-assistant.html", res));
    app.get('/tools/track-ip', (req, res) => serveHtml("track-ip.html", res));
    app.get('/tools/ig-stalk', (req, res) => serveHtml("ig-stalk.html", res));
    app.get('/tools/tiktok-dl', (req, res) => serveHtml("tiktok-dl.html", res));
    app.get('/tools/tiktok-stalk', (req, res) => serveHtml("tiktok-stalk.html", res));
    app.get('/tools/tts-gen', (req, res) => serveHtml("tts.html", res));
    app.get('/tools/ig-dl', (req, res) => serveHtml("igdl.html", res));
    app.get('/tools/cek-id-gc', (req, res) => serveHtml("cekgc.html", res));
    app.get('/tools/figure-gen', (req, res) => serveHtml("figure.html", res));
    app.get('/tools/code-snap', (req, res) => serveHtml("codesnap.html", res));
    app.get("/tools/cek-id-ch", (req, res) => serveHtml("cekid.html", res));
    app.get("/tools/ngl-spam", (req, res) => serveHtml("ngl.html", res));
    app.get("/tools/react-channel", (req, res) => serveHtml("react.html", res));

};