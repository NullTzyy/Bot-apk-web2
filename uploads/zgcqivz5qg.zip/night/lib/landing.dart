// landing.dart - Dark Red & Light Red theme

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'login_page.dart';

void main() {
  runApp(const MaterialApp(
    home: LandingPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  // Red theme colors
  static const Color _darkBg = Color(0xFF090C10);
  static const Color _accentRed = Color(0xFFE53935);      // Bright Red
  static const Color _darkRed = Color(0xFF8B0000);        // Dark Red
  static const Color _cardBg = Color(0xFF12181F);
  static const Color _innerCardBg = Color(0xFF1A222B);
  static const Color _telegramBlue = Color(0xFF24A1DE);

  Future<void> _launchSocialUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        debugPrint("Could not launch $urlString");
      }
    } catch (e) {
      debugPrint("Error launching URL: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _darkBg,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildLogoSection(),
              _buildHeaderTitle(),
              const SizedBox(height: 40),
              _buildFeatureCard(),
              const SizedBox(height: 35),
              _buildActionButtons(context),
              const SizedBox(height: 25),
              _buildSocialSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildLogoSection() {
    return Container(
      width: double.infinity,
      height: 200,
      margin: const EdgeInsets.only(bottom: 10),
      child: Image.asset(
        'assets/images/logo.jpg',
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) =>
            const Icon(Icons.broken_image, color: Colors.white10, size: 80),
      ),
    );
  }

  Widget _buildHeaderTitle() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.baseline,
          textBaseline: TextBaseline.alphabetic,
          children: [
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFE8FFFF), Color(0xFFB8FFF3), _accentRed],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ).createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
              child: const Text(
                "X CUBE'",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 10,
                ),
              ),
            ),
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFE8FFFF), Color(0xFFB8FFF3), _accentRed],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ).createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height)),
              child: const Text(
                "X",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  fontSize: 40,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 10,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Text(
          "GACOR  •  TERUPDATE  •  STABIL",
          style: TextStyle(
            color: _accentRed.withOpacity(0.5),
            fontSize: 11,
            letterSpacing: 4,
            fontWeight: FontWeight.w300,
          ),
        ),
      ],
    );
  }

  Widget _buildFeatureCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _innerCardBg,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.shield_outlined, color: _accentRed, size: 32),
          ),
          const SizedBox(height: 20),
          const Text(
            "X-STRIKE BUG",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              letterSpacing: 2,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          Text(
            "Aplikasi dengan desain elegan dan fitur terbaru.\nPengembangan langsung oleh TEAM X-STRIKE",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(0.5),
              fontSize: 13,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    const TextStyle rajdhaniStyle = TextStyle(
      fontFamily: 'Orbitron',
      fontWeight: FontWeight.w600,
      fontSize: 16,
    );

    return Column(
      children: [
        _customButton(
          title: "LOGIN TO X-STRIKE",
          icon: FontAwesomeIcons.rocket,
          isPrimary: true,
          textStyle: rajdhaniStyle,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          ),
        ),
        const SizedBox(height: 16),
        _customButton(
          title: "CONTACT SUPPORT",
          icon: Icons.support_agent,
          isPrimary: false,
          textStyle: rajdhaniStyle,
          onTap: () => _launchSocialUrl("https://t.me/maklowlacur"),
        ),
      ],
    );
  }

  Widget _buildSocialSection() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 25, horizontal: 20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Colors.white.withOpacity(0.03)),
      ),
      child: Column(
        children: [
          Text(
            "HUBUNGI KAMI",
            style: TextStyle(
              fontFamily: 'Orbitron',
              color: Colors.white.withOpacity(0.3),
              fontSize: 11,
              letterSpacing: 3,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _socialIconItem(FontAwesomeIcons.telegram, "Telegram Dev", "https://t.me/AtomicModss", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.telegram, "Channel X-Strike", "https://t.me/allinfoxstrike", _telegramBlue),
              _socialIconItem(FontAwesomeIcons.tiktok, "TikTok Official", "https://tiktok.com/@lxishere", _accentRed),
            ],
          ),
        ],
      ),
    );
  }

  Widget _customButton({
    required String title,
    required IconData icon,
    required bool isPrimary,
    required VoidCallback onTap,
    TextStyle? textStyle,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          width: double.infinity,
          height: 60,
          decoration: BoxDecoration(
            color: isPrimary ? _accentRed.withOpacity(0.05) : Colors.white.withOpacity(0.015),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(
              color: isPrimary ? _accentRed.withOpacity(0.5) : Colors.white.withOpacity(0.07),
              width: 1.2,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isPrimary ? _accentRed : Colors.white54, size: 18),
              const SizedBox(width: 12),
              Text(
                title,
                style: (textStyle ?? const TextStyle()).copyWith(
                  color: isPrimary ? _accentRed : Colors.white60,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _socialIconItem(IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _launchSocialUrl(url),
      borderRadius: BorderRadius.circular(15),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _innerCardBg,
                border: Border.all(color: Colors.white.withOpacity(0.05)),
              ),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: Colors.white.withOpacity(0.6),
                fontSize: 10,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}