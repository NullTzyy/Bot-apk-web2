import 'package:flutter/material.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // Premium Red Color Palette
  static const Color primaryRed = Color(0xFFE53935);      // Vibrant Red
  static const Color darkRed = Color(0xFFC62828);         // Deep Dark Red
  static const Color lightRed = Color(0xFFEF5350);        // Soft Light Red
  static const Color accentRed = Color(0xFFFF5252);       // Bright Accent Red
  static const Color crimsonRed = Color(0xFFD32F2F);      // Crimson Touch
  static const Color roseRed = Color(0xFFFF6B6B);         // Rose Red

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Avengers - Red Edition',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        
        // Custom color scheme dengan warna merah premium
        colorScheme: const ColorScheme.dark().copyWith(
          primary: primaryRed,
          secondary: accentRed,
          tertiary: lightRed,
          error: crimsonRed,
          surface: Color(0xFF1A1A1A),
          onPrimary: Colors.white,
          onSecondary: Colors.white,
        ),
        
        // Custom AppBar Theme
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          iconTheme: IconThemeData(color: primaryRed),
          titleTextStyle: TextStyle(
            color: primaryRed,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
            letterSpacing: 2,
          ),
        ),
        
        // Custom Button Themes
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryRed,
            foregroundColor: Colors.white,
            elevation: 5,
            shadowColor: primaryRed.withOpacity(0.3),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ),
        
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            foregroundColor: primaryRed,
            side: BorderSide(color: primaryRed, width: 2),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
            ),
          ),
        ),
        
        textButtonTheme: TextButtonThemeData(
          style: TextButton.styleFrom(
            foregroundColor: primaryRed,
            textStyle: const TextStyle(
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        
        // Custom Input Decoration Theme
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withOpacity(0.05),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: primaryRed.withOpacity(0.2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: accentRed, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.redAccent, width: 1),
          ),
          labelStyle: TextStyle(color: primaryRed.withOpacity(0.7)),
          hintStyle: TextStyle(color: primaryRed.withOpacity(0.5)),
          prefixIconColor: primaryRed,
          suffixIconColor: primaryRed,
        ),
        
        // Custom Card Theme
        cardTheme: CardTheme(
          color: Colors.white.withOpacity(0.05),
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: BorderSide(color: primaryRed.withOpacity(0.2)),
          ),
          shadowColor: primaryRed.withOpacity(0.1),
        ),
        
        // Custom Dialog Theme
        dialogTheme: DialogTheme(
          backgroundColor: Colors.black.withOpacity(0.95),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: primaryRed.withOpacity(0.3), width: 1),
          ),
          titleTextStyle: TextStyle(
            color: primaryRed,
            fontSize: 20,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
          contentTextStyle: const TextStyle(
            color: Colors.white70,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        
        // Custom Bottom Navigation Bar Theme
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: Colors.transparent,
          selectedItemColor: primaryRed,
          unselectedItemColor: Colors.white54,
          type: BottomNavigationBarType.fixed,
          elevation: 0,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          selectedLabelStyle: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 12,
            fontWeight: FontWeight.bold,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'ShareTechMono',
            fontSize: 12,
          ),
        ),
        
        // Custom Tab Bar Theme
        tabBarTheme: const TabBarTheme(
          labelColor: primaryRed,
          unselectedLabelColor: Colors.white54,
          indicatorColor: primaryRed,
          dividerColor: Colors.transparent,
          labelStyle: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
          unselectedLabelStyle: TextStyle(
            fontFamily: 'ShareTechMono',
          ),
        ),
        
        // Custom Progress Indicator Theme
        progressIndicatorTheme: const ProgressIndicatorThemeData(
          color: primaryRed,
          circularTrackColor: Colors.white24,
          linearTrackColor: Colors.white24,
        ),
        
        // Custom SnackBar Theme
        snackBarTheme: SnackBarThemeData(
          backgroundColor: Colors.black.withOpacity(0.95),
          contentTextStyle: const TextStyle(color: Colors.white),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: primaryRed.withOpacity(0.3)),
          ),
          behavior: SnackBarBehavior.floating,
        ),
        
        // Custom Divider Theme
        dividerTheme: DividerThemeData(
          color: primaryRed.withOpacity(0.2),
          thickness: 1,
          space: 20,
        ),
        
        // Custom Switch Theme
        switchTheme: SwitchThemeData(
          thumbColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return primaryRed;
            }
            return Colors.white54;
          }),
          trackColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return primaryRed.withOpacity(0.5);
            }
            return Colors.white24;
          }),
        ),
        
        // Custom Checkbox Theme
        checkboxTheme: CheckboxThemeData(
          fillColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return primaryRed;
            }
            return null;
          }),
          checkColor: WidgetStateProperty.all(Colors.white),
          side: BorderSide(color: primaryRed.withOpacity(0.5), width: 2),
        ),
        
        // Custom Radio Theme
        radioTheme: RadioThemeData(
          fillColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return primaryRed;
            }
            return null;
          }),
        ),
        
        // Custom Slider Theme
        sliderTheme: SliderThemeData(
          activeTrackColor: primaryRed,
          inactiveTrackColor: primaryRed.withOpacity(0.2),
          thumbColor: accentRed,
          overlayColor: accentRed.withOpacity(0.1),
          trackHeight: 4,
          thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
          overlayShape: const RoundSliderOverlayShape(overlayRadius: 16),
        ),
        
        // Custom Navigation Rail Theme
        navigationRailTheme: const NavigationRailThemeData(
          backgroundColor: Colors.transparent,
          selectedIconTheme: IconThemeData(color: primaryRed),
          unselectedIconTheme: IconThemeData(color: Colors.white54),
          selectedLabelTextStyle: TextStyle(color: primaryRed),
          unselectedLabelTextStyle: TextStyle(color: Colors.white54),
        ),
        
        // Custom Time Picker Theme
        timePickerTheme: TimePickerThemeData(
          backgroundColor: Colors.black.withOpacity(0.95),
          hourMinuteTextColor: primaryRed,
          dialBackgroundColor: primaryRed.withOpacity(0.1),
          dialHandColor: primaryRed,
          dialTextColor: Colors.white,
          entryModeIconColor: primaryRed,
          helpTextStyle: TextStyle(color: primaryRed),
          hourMinuteTextStyle: const TextStyle(color: primaryRed),
        ),
        
        // Custom Date Picker Theme
        datePickerTheme: DatePickerThemeData(
          backgroundColor: Colors.black.withOpacity(0.95),
          headerBackgroundColor: primaryRed,
          headerForegroundColor: Colors.white,
          dayBackgroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return primaryRed;
            }
            return null;
          }),
          dayForegroundColor: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return Colors.white;
            }
            return Colors.white70;
          }),
        ),
      ),
      
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(
              builder: (_) => const LoginPage(),
              settings: const RouteSettings(name: '/'),
            );

          case '/buy_account':
            return MaterialPageRoute(
              builder: (_) => const BuyAccountPage(),
              settings: const RouteSettings(name: '/buy_account'),
            );

          case '/loader':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'],
                password: args['password'],
                role: args['role'],
                sessionKey: args['key'],
                expiredDate: args['expiredDate'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listPayload: List<Map<String, dynamic>>.from(args['listPayload'] ?? []),
                listDDoS: List<Map<String, dynamic>>.from(args['listDDoS'] ?? []),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
              settings: const RouteSettings(name: '/loader'),
            );

          case '/attack':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AttackPage(
                username: args['username'],
                password: args['password'],
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'],
                expiredDate: args['expiredDate'],
                sessionKey: args['sessionKey'],
              ),
              settings: const RouteSettings(name: '/attack'),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => SellerPage(
                keyToken: args['keyToken'],
              ),
              settings: const RouteSettings(name: '/seller'),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => AdminPage(
                sessionKey: args['sessionKey'],
              ),
              settings: const RouteSettings(name: '/admin'),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => Scaffold(
                body: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.black,
                        primaryRed.withOpacity(0.1),
                        Colors.black,
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.error_outline,
                          color: primaryRed,
                          size: 80,
                        ),
                        SizedBox(height: 20),
                        Text(
                          "404 - Page Not Found",
                          style: TextStyle(
                            color: primaryRed,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(height: 10),
                        Text(
                          "The page you are looking for does not exist",
                          style: TextStyle(
                            color: Colors.white54,
                            fontSize: 14,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              settings: const RouteSettings(name: '/404'),
            );
        }
      },
    );
  }
}