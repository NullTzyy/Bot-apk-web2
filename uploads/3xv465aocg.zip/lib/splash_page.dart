import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  late VideoPlayerController _controller;

  // Warna merah yang digunakan
  static const primaryRed = Color(0xFFEF4444);
  static const lightRed = Color(0xFFFCA5A5);
  static const darkRed = Color(0xFFDC2626);

  @override
  void initState() {
    super.initState();

    // Load video dari assets
    _controller = VideoPlayerController.asset("assets/videos/splash.mp4")
      ..initialize().then((_) {
        setState(() {}); // rebuild setelah video siap
        _controller.play(); // auto play
      });

    _controller.setLooping(false); // splash cuma sekali
    _controller.addListener(() {
      // kalau sudah selesai, pindah ke login
      if (_controller.value.isInitialized &&
          !_controller.value.isPlaying &&
          _controller.value.position >= _controller.value.duration) {
        Navigator.pushReplacementNamed(context, '/');
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.5,
            colors: [
              Colors.black,
              Colors.black.withOpacity(0.95),
              primaryRed.withOpacity(0.05),
            ],
            stops: const [0.6, 0.8, 1.0],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Video dengan border merah
              Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: primaryRed.withOpacity(0.5),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: primaryRed.withOpacity(0.3),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: _controller.value.isInitialized
                    ? ClipOval(
                        child: SizedBox(
                          height: 160,
                          width: 160,
                          child: AspectRatio(
                            aspectRatio: _controller.value.aspectRatio,
                            child: VideoPlayer(_controller),
                          ),
                        ),
                      )
                    : Container(
                        height: 160,
                        width: 160,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey.shade900,
                        ),
                        child: const Center(
                          child: CircularProgressIndicator(
                            color: primaryRed,
                          ),
                        ),
                      ),
              ),

              const SizedBox(height: 30),

              // Progress bar dengan warna merah
              Container(
                width: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: primaryRed.withOpacity(0.3),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: LinearProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(primaryRed),
                  backgroundColor: Colors.white12,
                  minHeight: 5,
                  borderRadius: BorderRadius.circular(8),
                ),
              ),

              const SizedBox(height: 20),

              // Tulisan versi dengan efek glow merah
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [
                    BoxShadow(
                      color: primaryRed.withOpacity(0.2),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Image.asset(
                  'assets/images/title.png',
                  height: 40,
                  fit: BoxFit.contain,
                  color: primaryRed,
                  colorBlendMode: BlendMode.srcIn,
                ),
              ),

              const SizedBox(height: 10),

              // Teks loading tambahan
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: primaryRed.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: primaryRed.withOpacity(0.8),
                    ),
                  ),
                  const SizedBox(width: 4),
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: primaryRed,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    "LOADING",
                    style: TextStyle(
                      color: lightRed,
                      fontSize: 10,
                      letterSpacing: 2,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}