package com.nova.ronova;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
