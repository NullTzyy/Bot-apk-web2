import 'dart:convert';
import 'dart:core';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:ui' as ui;
import 'package:cached_network_image/cached_network_image.dart';
import 'bugs/bug_sender.dart';
import 'manager/admin_page.dart';
import 'bugs/home_page.dart';
import 'info/tqto.dart';
import 'info/info.dart';
import 'manager/change_password_page.dart';
import 'package:intl/intl.dart';
import 'dart:async';
import 'info/chat.dart';
import 'tools/load_tools.dart';
import 'login_page.dart';
import 'bugs/ddos_panel.dart';
import 'floating/floating_bug.dart';
import 'floating/floating_bagger.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with WidgetsBindingObserver, TickerProviderStateMixin {
  late AnimationController _controller;
  late AnimationController _fadeController;
  late Animation<double> _animation;
  late Animation<double> _fadeAnimation;
  String? sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  Timer? _clockTimer;
  DateTime _now = DateTime.now();

  int _selectedTabIndex = 0;
  Widget _selectedPage = const Center(child: CircularProgressIndicator());

  final Color primaryDark = const Color(0xFF000000);
  final Color cardDark = const Color(0xFF1A1A1A);
  final Color cardDarker = const Color(0xFF0D0D0D);
  final Color goldColor = const Color(0xFFFF1744);
  final Color blueColor = const Color(0xFF4A9EFF);

  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  bool _isLoadingKey = false;
  bool _isFloatingBaggerActive = false;

  @override
  void initState() {
    super.initState();    
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.5),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _pulseAnimation = Tween<double>(begin: 0.95, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _controller.forward();
    _fadeController.forward();

    _selectedPage = const Center(child: CircularProgressIndicator());

    _initAndroidIdAndConnect();
    _getSessionKey();
    _checkFloatingBaggerStatus();
  }
  
  Future<void> _checkFloatingBaggerStatus() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _isFloatingBaggerActive = prefs.getBool('floating_bagger_running') ?? false;
    });
  }
  
  Future<void> _getSessionKey() async {
    setState(() {
      _isLoadingKey = true;
    });

    try {
      final response = await http.get(
        Uri.parse(
            "http://aryaxpo.myserverr.web.id:2691/getKey?username=${widget.username}"),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true) {
          if (!mounted) return;
          setState(() {
            sessionKey = data['key'];
            _isLoadingKey = false;
            _selectedPage = _buildNewsPage();
          });
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoadingKey = false;
      });
    }
  }
  
  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
  }
  
  void _onTabTapped(int index) {
    if (sessionKey == null) return;

    setState(() {
      _selectedTabIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          sessionKey: sessionKey!,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
        );
      } else if (index == 2) {
        _selectedPage = CommunityPage(
          username: username,
          role: role,
        );
      }
    });
  }

  void _onDrawerItemSelected(int index) {
    if (sessionKey == null) return;

    setState(() {
      if (index == 4) {
        _selectedPage = ChangePasswordPage(username: username, sessionKey: sessionKey!);
      } else if (index == 5 || index == 6) {
        _selectedPage = AdminPage(sessionKey: sessionKey!, currentUserRole: role);
      }
    });
  }

  Widget _buildNewsPage() {
    return FadeTransition(
      opacity: _fadeAnimation,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildProfileCard(),
            const SizedBox(height: 12),
            _buildNewsList(),
            const SizedBox(height: 24),
            _buildStatsCards(),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _buildManageBugSenderButton()),
                const SizedBox(width: 12),
                Expanded(child: _buildToolsButton()),
              ],
            ),
            const SizedBox(height: 12),
            _buildDDosPanelButton(),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _buildChannelButton()),
                const SizedBox(width: 12),
                Expanded(child: _buildDeveloperButton()),
              ],
            ),
            const SizedBox(height: 12),
            _buildFloatingBaggerToggle(),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
  
  Widget _buildGlassCard({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1.5,
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildProfileCard() {
    return _buildGlassCard(
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [primaryDark, cardDarker],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(
                color: Colors.white.withOpacity(0.2),
                width: 2,
              ),
            ),
            child: Stack(
              children: [
                CircleAvatar(
                  radius: 32,
                  backgroundColor: cardDark,
                  child: Icon(Icons.person, color: goldColor, size: 32),
                ),
                Positioned(
                  bottom: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: primaryDark,
                      shape: BoxShape.circle,
                      border: Border.all(color: goldColor.withOpacity(0.6), width: 1.5),
                    ),
                    child: Icon(Icons.verified, color: goldColor, size: 14),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 22,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    color: goldColor.withOpacity(0.8),
                    fontSize: 13,
                    letterSpacing: 1.2,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cardDark, cardDarker],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: goldColor.withOpacity(0.3),
                width: 1,
              ),
            ),
            child: Text(
              "EXP: $expiredDate",
              style: TextStyle(
                color: goldColor,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.5,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildNewsList() {
    if (newsList.isEmpty) return const SizedBox.shrink();  
    final item = newsList[0];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        width: double.infinity,
        height: 280,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(
            color: goldColor.withOpacity(0.3),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: primaryDark.withOpacity(0.5),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (item['image'] != null && item['image'].toString().isNotEmpty)
                NewsMedia(url: item['image']),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      primaryDark.withOpacity(0.8),
                      Colors.transparent,
                      goldColor.withOpacity(0.1),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Account Statistics",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _buildStatCard(
                icon: Icons.person,
                title: "Username",
                value: username,
                color: blueColor,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildStatCard(
                icon: Icons.verified_user,
                title: "Role",
                value: role.toUpperCase(),
                color: _getRoleColor(role),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        _buildStatCard(
          icon: Icons.calendar_today,
          title: "Account Expires",
          value: expiredDate,
          color: goldColor,
          fullWidth: true,
        ),
      ],
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    bool fullWidth = false,
  }) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, cardDarker],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: primaryDark.withOpacity(0.5),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.7),
                    fontSize: 14,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor(String role) {
    switch (role.toLowerCase()) {
      case "owner":
        return Colors.red;
      case "admin":
        return Colors.green;
      case "reseller":
        return Colors.orange;
      default:
        return goldColor;
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: cardDarker,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [cardDark, cardDarker],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "X PARADOX",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 16),
                _buildDrawerInfo("User:", username),
                _buildDrawerInfo("Role:", role),
                _buildDrawerInfo("Expired:", expiredDate),
              ],
            ),
          ),
          const SizedBox(height: 16),
          _buildDrawerItem(
            icon: Icons.person,
            label: "My Info",
            onTap: () {
              if (sessionKey == null) return;
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MyInfoPage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey!,
                  ),
                ),
              );
            },
          ),
          _buildDrawerItem(
            icon: Icons.group,
            label: "Thanks To",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ThanksToPage()),
              );
            },
          ),
          if (role != "member")
            _buildDrawerItem(
              icon: Icons.admin_panel_settings,
              label: "User Management",
              onTap: () {
                if (sessionKey == null) return;
                Navigator.pop(context);
                _onDrawerItemSelected(6);
              },
            ),
          const Divider(color: Colors.white24),
          _buildDrawerItem(
            icon: Icons.logout,
            label: "Logout",
            onTap: () async {
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
          ),
        ],
      ),
    );
  }

  void _showFloatingBugMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
          border: Border.all(color: Colors.white.withOpacity(0.1)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "Floating Bug",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.android, color: Colors.green),
              title: const Text(
                "Di Dalam Aplikasi",
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                "Muncul di dalam APK",
                style: TextStyle(color: Colors.white.withOpacity(0.6)),
              ),
              onTap: () {
                Navigator.pop(context);
                FloatingBugService().toggleEnabled();
              },
            ),
            const Divider(color: Colors.white24),
            ListTile(
              leading: const Icon(Icons.chat_bubble, color: Colors.blue),
              title: const Text(
                "Di Luar Aplikasi",
                style: TextStyle(color: Colors.white),
              ),
              subtitle: Text(
                "Muncul di semua layar",
                style: TextStyle(color: Colors.white.withOpacity(0.6)),
              ),
              onTap: () {
                Navigator.pop(context);
                _toggleFloatingBagger();
              },
            ),
          ],
        ),
      ),
    );
  }
  Future<void> _toggleFloatingBagger() async {
    final hasPermission = await FloatingBagger.checkOverlayPermission();
    if (!hasPermission) {
      final granted = await FloatingBagger.requestOverlayPermission();
      if (!granted) {
        _showAlert("❌ Izin Ditolak", 
            "Aktifkan izin 'Tampilkan di atas aplikasi lain' di pengaturan");
        return;
      }
    }
    
    final prefs = await SharedPreferences.getInstance();
    final isServiceRunning = prefs.getBool('floating_bagger_running') ?? false;
    
    if (isServiceRunning) {
      await FloatingBagger.stopService();
      await prefs.setBool('floating_bagger_running', false);
      setState(() {
        _isFloatingBaggerActive = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Dimatikan")),
      );
    } else {
      await FloatingBagger.startService(
        username: username,
        password: password,
        sessionKey: sessionKey!,
        role: role,
        expiredDate: expiredDate,
      );
      await prefs.setBool('floating_bagger_running', true);
      setState(() {
        _isFloatingBaggerActive = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Floating Bagger Diaktifkan")),
      );
    }
  }

  Widget _buildFloatingBaggerToggle() {
    return GestureDetector(
      onTap: _toggleFloatingBagger,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _isFloatingBaggerActive
                ? Colors.green.withOpacity(0.5)
                : goldColor.withOpacity(0.3),
            width: 1
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _isFloatingBaggerActive
                    ? Colors.green.withOpacity(0.2)
                    : Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.chat_bubble,
                color: _isFloatingBaggerActive
                    ? Colors.green
                    : blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Floating Bagger (Luar Aplikasi)",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    _isFloatingBaggerActive
                        ? "Aktif - Tap untuk matikan"
                        : "Nonaktif - Tap untuk aktifkan",
                    style: TextStyle(
                      color: _isFloatingBaggerActive
                          ? Colors.green.withOpacity(0.8)
                          : Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              _isFloatingBaggerActive
                  ? Icons.toggle_on
                  : Icons.toggle_off,
              color: _isFloatingBaggerActive
                  ? Colors.green
                  : goldColor,
              size: 30,
            ),
          ],
        ),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ui.ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.all(24),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      cardDark.withOpacity(0.95),
                      cardDarker.withOpacity(0.98),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.15),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 30,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: title.contains('✅')
                              ? [
                                  Colors.green.withOpacity(0.3),
                                  const Color(0xFF00FF88).withOpacity(0.3),
                                ]
                              : [
                                  const Color(0xFFDC143C).withOpacity(0.3),
                                  const Color(0xFFFF416C).withOpacity(0.3),
                                ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Icon(
                        title.contains('✅')
                            ? Icons.check_circle
                            : Icons.error,
                        color: Colors.white,
                        size: 40,
                      ),
                    ),
                    const SizedBox(height: 24),
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        msg,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 15,
                          height: 1.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 32),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: title.contains('✅')
                              ? const Color(0xFF00FF88).withOpacity(0.2)
                              : const Color(0xFFDC143C).withOpacity(0.2),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(16),
                            side: BorderSide(
                              color: title.contains('✅')
                                  ? const Color(0xFF00FF88).withOpacity(0.5)
                                  : const Color(0xFFDC143C).withOpacity(0.5),
                              width: 1.5,
                            ),
                          ),
                          elevation: 0,
                        ),
                        child: Text(
                          "OK",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.2,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildManageBugSenderButton() {
    return GestureDetector(
      onTap: () {
        if (sessionKey == null) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => BugSenderPage(
              sessionKey: sessionKey!,
              username: username,
              role: role,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.whatsapp,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Bug Sender",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Manage WhatsApp",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildToolsButton() {
    return GestureDetector(
      onTap: () {
        if (sessionKey == null) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ToolsPage(
              sessionKey: sessionKey!,
              username: username,
              userRole: role,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.build_circle_outlined,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Tools",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Digital Tools",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildDDosPanelButton() {
    return GestureDetector(
      onTap: () {
        if (sessionKey == null) return;
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AttackPanel(
              sessionKey: sessionKey!,
              listDDoS: listDoos,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.server,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Attack",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "DDos Panel",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildChannelButton() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse("https://t.me/ellexplore");
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.telegram,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Telegram",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Join Update Channel",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDeveloperButton() {
    return GestureDetector(
      onTap: () async {
        final uri = Uri.parse("https://t.me/primroseell");
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [cardDark, cardDarker],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: goldColor.withOpacity(0.3), width: 1),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                FontAwesomeIcons.telegram,
                color: blueColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Telegram",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const Text(
                    "Contact Developer",
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: goldColor,
              size: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 14,
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            style: TextStyle(
              color: goldColor,
              fontSize: 14,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: goldColor),
      title: Text(
        label,
        style: const TextStyle(color: Colors.white),
      ),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (sessionKey == null) {
      return Scaffold(
        backgroundColor: primaryDark,
        body: Center(child: CircularProgressIndicator(color: goldColor)),
      );
    }    
    final double bottomPadding = MediaQuery.of(context).padding.bottom;
    return Scaffold(
      backgroundColor: primaryDark,
      appBar: AppBar(
        title: Text(
          "Holaa, $username",
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: primaryDark,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_circle, color: Colors.white),
            onPressed: () {
              if (sessionKey == null) return;
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => MyInfoPage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey!,
                  ),
                ),
              );
            },
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: FadeTransition(opacity: _animation, child: _selectedPage),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(
          left: 20.0,
          right: 20.0,
          bottom: bottomPadding + 16.0,
        ),
        child: Container(
          height: 72.0,
          decoration: BoxDecoration(
            color: cardDark.withOpacity(0.8),
            borderRadius: BorderRadius.circular(28.0),
            border: Border.all(
              color: goldColor.withOpacity(0.3),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: primaryDark.withOpacity(0.5),
                blurRadius: 25,
                spreadRadius: 3,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(28.0),
                child: BackdropFilter(
                  filter: ui.ImageFilter.blur(
                    sigmaX: 15.0,
                    sigmaY: 15.0,
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12.0),
                    child: BottomNavigationBar(
                      backgroundColor: Colors.transparent,
                      selectedItemColor: goldColor,
                      unselectedItemColor: Colors.white70,
                      currentIndex: _selectedTabIndex,
                      onTap: _onTabTapped,
                      type: BottomNavigationBarType.fixed,
                      elevation: 0,
                      showSelectedLabels: true,
                      showUnselectedLabels: true,
                      selectedLabelStyle: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                      unselectedLabelStyle: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                      selectedFontSize: 12,
                      unselectedFontSize: 11,
                      iconSize: 24.0,
                      items: [
                        BottomNavigationBarItem(
                          icon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(Icons.home_outlined),
                          ),
                          activeIcon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(Icons.home),
                          ),
                          label: "Home",
                        ),
                        BottomNavigationBarItem(
                          icon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(FontAwesomeIcons.whatsapp, size: 20),
                          ),
                          activeIcon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(FontAwesomeIcons.whatsapp, size: 20),
                          ),
                          label: "WhatsApp",
                        ),
                        BottomNavigationBarItem(
                          icon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(Icons.chat_bubble_outline, size: 20),
                          ),
                          activeIcon: Container(
                            padding: const EdgeInsets.symmetric(vertical: 8.0),
                            child: const Icon(Icons.chat_bubble, size: 20),
                          ),
                          label: "Chat",
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _fadeController.dispose();
    _pulseController.dispose();
    _slideController.dispose();
    _clockTimer?.cancel();
    super.dispose();
  }
}

class NewsMedia extends StatelessWidget {
  final String url;

  const NewsMedia({required this.url});

  @override
  Widget build(BuildContext context) {
    return CachedNetworkImage(
      imageUrl: url,
      fit: BoxFit.cover,
      placeholder: (context, url) => Container(
        color: const Color(0xFF1A1A1A),
        child: const Center(
          child: CircularProgressIndicator(color: Color(0xFFFF1744)),
        ),
      ),
      errorWidget: (context, url, error) => Container(
        color: const Color(0xFF2D2D2D),
        child: const Center(
          child: Icon(Icons.error, color: Colors.white70),
        ),
      ),
    );
  }
}