module.exports = {
  tokens: "8859662119:AAHxj6Md97FGtH96JXSNle-rLkzAtwzsaAE", 
  owner: "6311125849", 
  port: "2306", // Ini Wajib Jangan Diubah
  ipvps: "http://indryblabla.pterodacytl.my.id:2245" // Jangan Diubah Nanti Eror!!
};