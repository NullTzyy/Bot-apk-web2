module.exports = {
  BOT_TOKEN: "8859662119:AAHxj6Md97FGtH96JXSNle-rLkzAtwzsaAE", // isi token bot lu
};