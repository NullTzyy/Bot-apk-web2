// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:http/http.dart' as http;
import 'dart:ui';

import 'telegram.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';
import 'spams_page.dart';
import 'public_page.dart';
import 'device_dashboard.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  VideoPlayerController? _videoController;
  VideoPlayerController? _statsVideoController; 

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;
  String androidId = "unknown";

  int _selectedIndex = 0;
  Widget _selectedPage = const Placeholder();

  final GlobalKey _bugButtonKey = GlobalKey();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  final PageController _pageController = PageController(viewportFraction: 0.92);
  int _currentNewsIndex = 0;

  List<Map<String, dynamic>> _activityLogs = [];
  bool _isLoadingActivityLogs = false;
  bool _hasActivityLogsError = false;

  Offset _assistiveTouchPosition = const Offset(20, 150);
  bool _isAssistiveMenuOpen = false;
  
  bool _isBugToolsExpanded = false;
  String _activePage = 'home';

  @override
  void initState() {
    super.initState();
    
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();

    _initAndroidIdAndConnect();
    _fetchActivityLogs();
    _initVideoBackground();
  }

  Future<void> _initVideoBackground() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/heder.mp4')
        ..initialize().then((_) {
          _videoController?.setLooping(true);
          _videoController?.setVolume(0.0);
          _videoController?.play();
          if (mounted) setState(() {});
        }).catchError((e) {
          debugPrint("Gagal memuat video background: $e");
        });

      _statsVideoController = VideoPlayerController.asset('assets/videos/stats.mp4')
        ..initialize().then((_) {
          _statsVideoController?.setLooping(true);
          _statsVideoController?.setVolume(0.0);
          _statsVideoController?.play();
          if (mounted) setState(() {});
        }).catchError((e) {
          debugPrint("Gagal memuat video stats: $e");
        });
    } catch (e) {
       debugPrint("Exception saat memuat video: $e");
    }
  }

  void _toggleStatsVideo() {
    setState(() {
      if (_statsVideoController != null) {
        if (_statsVideoController!.value.isPlaying) {
          _statsVideoController!.pause();
        } else {
          _statsVideoController!.play();
        }
      }
    });
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    if(mounted) {
      setState(() {
        androidId = deviceInfo.id;
      });
    }
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('http://manipulator.panel.serverku.space:2026'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
    });
  }

  Future<void> _fetchActivityLogs() async {
    if(!mounted) return;
    setState(() {
      _isLoadingActivityLogs = true;
      _hasActivityLogsError = false;
    });

    try {
      final response = await http.get(
        Uri.parse('http://manipulator.panel.serverku.space:2026/api/user/getActivityLogs?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true && data['logs'] != null) {
          if(mounted) {
             setState(() {
              _activityLogs = List<Map<String, dynamic>>.from(data['logs']);
              _isLoadingActivityLogs = false;
            });
          }
        } else {
          if(mounted) {
             setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
          }
        }
      } else {
         if(mounted) {
            setState(() {
              _isLoadingActivityLogs = false;
              _hasActivityLogsError = true;
            });
         }
      }
    } catch (e) {
      print('Error fetching activity logs: $e');
      if(mounted) {
        setState(() {
          _isLoadingActivityLogs = false;
          _hasActivityLogsError = true;
        });
      }
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: const Color(0xFFE0E0E0).withOpacity(0.3), width: 1),
        ),
        title: const Text("⚠️ Session Expired", style: TextStyle(color: Colors.white, fontFamily: "Orbitron")),
        content: Text(message, style: const TextStyle(color: Colors.white70, fontFamily: "ShareTechMono")),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                    (route) => false,
              );
            },
            child: const Text("OK", style: TextStyle(color: Color(0xFFE0E0E0))),
          ),
        ],
      ),
    );
  }

  void _selectFromDrawer(String page) {
    if (page == 'account') {
      setState(() {
        _isAssistiveMenuOpen = false;
        _isBugToolsExpanded = false;
      });
      _showAccountMenu();
      return;
    }

    if (page == 'rat') {
      setState(() {
        _isAssistiveMenuOpen = false;
        _isBugToolsExpanded = false;
        _activePage = 'rat';
        _selectedPage = DeviceDashboardPage(username: username);
      });
      _controller.reset();
      _controller.forward();
      return;
    }

    setState(() {
      _isAssistiveMenuOpen = false;
      _activePage = page;
    });

    Widget nextWidget = _buildNewsPage();
    
    if (page == 'home') {
      _selectedIndex = 0;
      nextWidget = _buildNewsPage();
    } else if (page == 'bug') {
      nextWidget = AttackPage(
        username: username,
        password: password,
        listBug: listBug,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'custom_bug') {
      nextWidget = CustomAttackPage(
        username: username,
        password: password,
        listPayload: listPayload,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'group_bug') {
      nextWidget = GroupBugPage(
        username: username,
        password: password,
        role: role,
        expiredDate: expiredDate,
        sessionKey: sessionKey,
      );
    } else if (page == 'telegram') {
      nextWidget = TelegramSpamPage(sessionKey: sessionKey);
    } else if (page == 'ddos') {
      nextWidget = AttackPanel(sessionKey: sessionKey, listDDoS: listDDoS);
    } else if (page == 'tools') {
      nextWidget = ToolsPage(sessionKey: sessionKey, userRole: role);
    } else if (page == 'reseller') {
      nextWidget = SellerPage(keyToken: sessionKey);
    } else if (page == 'admin') {
      nextWidget = AdminPage(sessionKey: sessionKey);
    } else if (page == 'sender') {
      nextWidget = SenderPage(sessionKey: sessionKey);
    }

    setState(() {
      _selectedPage = nextWidget;
      _controller.reset();
      _controller.forward();
    });
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 12, 
        bottom: 12, 
        left: 16, 
        right: 16
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GestureDetector(
            onTap: () {
              setState(() {
                _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                if (_isAssistiveMenuOpen) {
                  _assistiveTouchPosition = Offset(16, MediaQuery.of(context).padding.top + 60);
                }
              });
            },
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: const Color(0xFF0A0D0B),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
              ),
              child: const Center(
                child: Icon(Icons.segment, color: Color(0xFF25D366), size: 28),
              ),
            ),
          ),
          Expanded(
            child: Container(
              height: 48,
              margin: const EdgeInsets.symmetric(horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: Colors.black45,
                border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    if (_videoController != null && _videoController!.value.isInitialized)
                      FittedBox(
                        fit: BoxFit.cover,
                        child: SizedBox(
                          width: _videoController!.value.size.width,
                          height: _videoController!.value.size.height,
                          child: VideoPlayer(_videoController!),
                        ),
                      )
                    else
                      Container(color: Colors.black87),
                    Container(color: Colors.black.withOpacity(0.2)),
                    const Center(
                      child: Text(
                        "NOCURE",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: "Orbitron",
                          letterSpacing: 2.0,
                          shadows: [Shadow(color: Colors.black, blurRadius: 4, offset: Offset(1, 1))]
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Row(
            children: [
              GestureDetector(
                onTap: _showAccountMenu,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0D0B),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
                  ),
                  child: const Center(
                    child: Icon(Icons.tune, color: Colors.white54, size: 24),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  _selectFromDrawer('tools');
                },
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: const Color(0xFF0A0D0B),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: Colors.white.withOpacity(0.05), width: 1),
                  ),
                  child: const Center(
                    child: Icon(Icons.apps, color: Colors.white54, size: 24),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
  
  Widget _buildAccountStatsCard() {
    const greenColor = Color(0xFF25D366);
    String displayUid = androidId != "unknown" ? androidId : "f4424219-4faf-4417-9dc5-57a862d202ba";
    String shortUid = displayUid.length > 12 ? "${displayUid.substring(0, 12)}..." : displayUid;
    
    bool isVideoPlaying = _statsVideoController != null && _statsVideoController!.value.isPlaying;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      height: 230, 
      decoration: BoxDecoration(
        color: const Color(0xFF0A0D0B),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.05), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 6),
          )
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16.5),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_statsVideoController != null && _statsVideoController!.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _statsVideoController!.value.size.width,
                  height: _statsVideoController!.value.size.height,
                  child: VideoPlayer(_statsVideoController!),
                ),
              )
            else
              Container(color: const Color(0xFF101412)),

            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.85),
                    Colors.black.withOpacity(0.6),
                    Colors.black.withOpacity(0.85),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.person, color: greenColor, size: 20),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                fontFamily: "Orbitron",
                                letterSpacing: 1.2,
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              "ID: $shortUid",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.5),
                                fontSize: 11,
                                fontFamily: "ShareTechMono",
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      GestureDetector(
                        onTap: _toggleStatsVideo,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
                          ),
                          child: Icon(
                            isVideoPlaying ? Icons.pause : Icons.play_arrow,
                            color: Colors.white70,
                            size: 16,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(ClipboardData(text: displayUid));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('UID Copied!', style: TextStyle(fontFamily: "ShareTechMono")),
                              backgroundColor: greenColor,
                              duration: Duration(seconds: 1),
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.4),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: Colors.white.withOpacity(0.1), width: 1),
                          ),
                          child: const Icon(Icons.copy, color: Colors.white70, size: 16),
                        ),
                      ),
                    ],
                  ),

                  Row(
                    children: [
                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: Colors.black,
                          border: Border.all(color: Colors.white.withOpacity(0.2), width: 1.5),
                          image: const DecorationImage(
                            image: AssetImage('assets/images/logo.png'), 
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildStatRowDetail(Icons.shield_outlined, "ROLE", role.toUpperCase(), greenColor),
                            const SizedBox(height: 10),
                            _buildStatRowDetail(Icons.calendar_today_outlined, "EXP DATE", expiredDate, Colors.white),
                            const SizedBox(height: 10),
                            _buildStatRowDetail(Icons.battery_charging_full, "BATTERY", "100%", greenColor),
                          ],
                        ),
                      ),
                    ],
                  ),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.cloud_queue, color: Colors.orangeAccent, size: 28),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "28°C",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "ShareTechMono",
                                ),
                              ),
                              Text(
                                "Partly Cloudy",
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.5),
                                  fontSize: 11,
                                  fontFamily: "ShareTechMono",
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.location_on, color: greenColor, size: 14),
                              const SizedBox(width: 4),
                              const Text(
                                "JAKARTA, ID",
                                style: TextStyle(
                                  color: greenColor,
                                  fontSize: 11,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "ShareTechMono",
                                  letterSpacing: 1.0,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "ROLE: ${role.toUpperCase()}",
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.4),
                              fontSize: 10,
                              fontFamily: "ShareTechMono",
                              letterSpacing: 1.0,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatRowDetail(IconData icon, String label, String value, Color valueColor) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: const Color(0xFF25D366), size: 16),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withOpacity(0.4),
                fontSize: 10,
                fontFamily: "ShareTechMono",
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                color: valueColor,
                fontSize: 13,
                fontWeight: FontWeight.bold,
                fontFamily: "ShareTechMono",
                letterSpacing: 1.0,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildWhatsAppCrashBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      height: 85,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF25D366), Color(0xFF128C7E)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF25D366).withOpacity(0.3),
            blurRadius: 10,
            spreadRadius: 1,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Stack(
        children: [
          Positioned(
            right: -10,
            top: -15,
            child: Icon(
              FontAwesomeIcons.whatsapp,
              size: 100,
              color: Colors.white.withOpacity(0.2),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    const Icon(
                      FontAwesomeIcons.whatsapp,
                      color: Colors.white,
                      size: 20,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      "WHATSAPP CRASH",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Orbitron",
                        letterSpacing: 1.0,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  "Send custom payloads to crash target WhatsApp.",
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 11,
                    fontFamily: "ShareTechMono",
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: const Color(0xFFE0E0E0),
      onRefresh: () async {
        await _fetchActivityLogs();
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(
            child: SizedBox(height: MediaQuery.of(context).padding.top + 70),
          ),
          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                _buildAccountStatsCard(), 
                const SizedBox(height: 15),
                _buildWhatsAppCrashBanner(),
                const SizedBox(height: 25),
                _buildNewsCarousel(),
                const SizedBox(height: 10),
                _buildRecentActivity(),
                const SizedBox(height: 120),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 180,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.black.withOpacity(0.3),
          border: Border.all(color: const Color(0xFFE0E0E0).withOpacity(0.2)),
        ),
        child: const Center(child: Text("No news available", style: TextStyle(color: Colors.white54))),
      );
    }

    return Column(
      children: [
        SizedBox(
          height: 280,
          child: PageView.builder(
            controller: _pageController,
            itemCount: newsList.length,
            onPageChanged: (index) {
              setState(() {
                _currentNewsIndex = index;
              });
            },
            itemBuilder: (context, index) {
              final item = newsList[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFF101412),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.08), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 10,
                      spreadRadius: 2,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      flex: 6,
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(14.5)),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            if (item['image'] != null && item['image'].toString().isNotEmpty)
                              NewsMedia(url: item['image'])
                            else
                              Container(color: Colors.black26),
                            Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.black.withOpacity(0.4),
                                    Colors.transparent,
                                  ],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.center,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      flex: 4,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.newspaper_outlined,
                                  color: Color(0xFF25D366),
                                  size: 22,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    item['title'] ?? "PPL Team",
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "Orbitron",
                                      letterSpacing: 1.0,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            Text(
                              item['desc'] ?? "Admin Bukan Pedofil Yak.",
                              style: TextStyle(
                                color: Colors.white.withOpacity(0.7),
                                fontSize: 13,
                                fontFamily: "ShareTechMono",
                                letterSpacing: 0.5,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        if (newsList.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                newsList.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 6,
                  width: _currentNewsIndex == index ? 24 : 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: _currentNewsIndex == index
                        ? const Color(0xFF25D366)
                        : Colors.white.withOpacity(0.2),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildRecentActivity() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "RECENT ACTIVITY",
            style: TextStyle(
              color: Color(0xFF25D366),
              fontSize: 14,
              fontWeight: FontWeight.w600,
              fontFamily: "Orbitron",
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 15),

          if (_isLoadingActivityLogs)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: const Center(
                child: CircularProgressIndicator(color: Color(0xFFE0E0E0)),
              ),
            )
          else if (_hasActivityLogsError)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: Colors.red.withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: const Center(
                child: Text(
                  "Failed to load activity logs",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else if (_activityLogs.isEmpty)
            Container(
              height: 120,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                color: Colors.black.withOpacity(0.3),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.2),
                  width: 1,
                ),
              ),
              child: const Center(
                child: Text(
                  "No activity logs available",
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 14,
                  ),
                ),
              ),
            )
          else
            ..._activityLogs.take(5).map((log) {
              final timestamp = DateTime.tryParse(log['timestamp'] ?? '') ?? DateTime.now();
              final formattedTime = _formatDateTime(timestamp);

              String activityText = log['activity'] ?? 'Unknown Activity';

              return Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF121413),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.05),
                      width: 1,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 5,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.history,
                        color: Colors.white54,
                        size: 16,
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Text(
                          activityText,
                          style: const TextStyle(
                            color: Colors.white70,
                            fontFamily: "ShareTechMono",
                            fontSize: 13,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Text(
                        formattedTime,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.3),
                          fontFamily: "ShareTechMono",
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
        ],
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    if (difference.inDays > 0) return '${difference.inDays} day${difference.inDays > 1 ? 's' : ''} ago';
    if (difference.inHours > 0) return '${difference.inHours} hour${difference.inHours > 1 ? 's' : ''} ago';
    if (difference.inMinutes > 0) return '${difference.inMinutes} minute${difference.inMinutes > 1 ? 's' : ''} ago';
    return 'Just now';
  }

  Widget _glassCard({required Widget child}) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.black.withOpacity(0.2),
        border: Border.all(
          color: const Color(0xFFE0E0E0).withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFE0E0E0).withOpacity(0.05),
            blurRadius: 20,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
          child: child,
        ),
      ),
    );
  }

  Widget _glassButton({required Icon icon, required Text label, required VoidCallback onPressed}) {
    return ElevatedButton.icon(
      icon: icon,
      label: label,
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.transparent,
        foregroundColor: const Color(0xFFE0E0E0),
        shadowColor: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: const Color(0xFFE0E0E0).withOpacity(0.3), width: 1),
        ),
      ),
      onPressed: onPressed,
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("Account Info", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Orbitron")),
                const SizedBox(height: 12),
                _infoCard(Icons.person, "Username", username),
                _infoCard(Icons.date_range, "Expired", expiredDate),
                _infoCard(Icons.security, "Role", role),
                const SizedBox(height: 20),
                _glassButton(
                  icon: const Icon(Icons.lock_reset),
                  label: const Text("Change Password"),
                  onPressed: () {
                    Navigator.pop(context);
                    setState(() {
                      _activePage = 'change_password';
                      _selectedPage = ChangePasswordPage(
                        username: username,
                        sessionKey: sessionKey,
                      );
                      _controller.reset();
                      _controller.forward();
                    });
                  },
                ),
                const SizedBox(height: 10),
                _glassButton(
                  icon: const Icon(Icons.logout),
                  label: const Text("Logout"),
                  onPressed: () async {
                    final prefs = await SharedPreferences.getInstance();
                    await prefs.clear();
                    if (!mounted) return;
                    Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => const LoginPage()),
                          (route) => false,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoCard(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE0E0E0).withOpacity(0.2), width: 1),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFE0E0E0)),
          const SizedBox(width: 10),
          Text("$label:", style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold)),
          const Spacer(),
          Text(value, style: const TextStyle(color: Colors.white, fontFamily: "ShareTechMono")),
        ],
      ),
    );
  }

  Widget _buildAssistiveMenu() {
    final String currentRole = role.toLowerCase();
    
    final bool canAccessAdmin = ['founder', 'moderator', 'high admin', 'owner'].contains(currentRole);
    final bool canAccessSeller = ['founder', 'moderator', 'high admin', 'owner', 'reseller'].contains(currentRole);
    final bool canAccessAllBugs = ['founder', 'moderator', 'high admin', 'owner'].contains(currentRole);
    final bool canAccessResellerBugs = ['reseller'].contains(currentRole);
    final bool isMember = !canAccessAllBugs && !canAccessResellerBugs;

    return Container(
      width: 240,
      decoration: BoxDecoration(
        color: const Color(0xFF0A0D0B),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.6),
            blurRadius: 15,
            spreadRadius: 2,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 8),
                _assistiveMenuItem(Icons.home, "Home", 'home'),
                Theme(
                  data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                  child: ExpansionTile(
                    tilePadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                    childrenPadding: EdgeInsets.zero,
                    leading: const Icon(FontAwesomeIcons.whatsapp, color: Colors.white70, size: 18),
                    title: const Text("Bug Tools", style: TextStyle(color: Colors.white70, fontSize: 14, fontFamily: "ShareTechMono", letterSpacing: 1.0)),
                    trailing: Icon(
                      _isBugToolsExpanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, 
                      color: Colors.white54, 
                      size: 18
                    ),
                    onExpansionChanged: (bool expanded) {
                      setState(() {
                        _isBugToolsExpanded = expanded;
                      });
                      if (isMember && expanded) {
                         setState(() {
                            _isBugToolsExpanded = false;
                         });
                         _selectFromDrawer('bug');
                      }
                    },
                    children: [
                      if (!isMember)
                        Padding(
                          padding: const EdgeInsets.only(left: 20, top: 4, bottom: 8, right: 16),
                          child: Stack(
                            children: [
                              Positioned(
                                left: 7, 
                                top: 12,
                                bottom: 12,
                                child: Container(
                                  width: 1.5,
                                  color: Colors.white24,
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (canAccessAllBugs || canAccessResellerBugs) ...[
                                    _buildTreeItem(
                                      icon: FontAwesomeIcons.usersSlash, 
                                      title: "Group Bug",
                                      page: 'group_bug',
                                    ),
                                    const SizedBox(height: 8),
                                  ],
                                  if (canAccessAllBugs) ...[
                                    _buildTreeItem(
                                      icon: Icons.terminal, 
                                      title: "Custom Bug",
                                      page: 'custom_bug',
                                    ),
                                    const SizedBox(height: 8),
                                  ],
                                  _buildTreeItem(
                                    icon: Icons.bolt, 
                                    title: "Basic Bug",
                                    page: 'bug',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
                _assistiveMenuItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
                _assistiveMenuItem(Icons.phone_android, "RAT", 'rat'),
                _assistiveMenuItem(FontAwesomeIcons.screwdriverWrench, "Tools", 'tools'),
                _assistiveMenuItem(Icons.security, "DDoS Attack", 'ddos'),
                const Divider(color: Colors.white12, height: 16, thickness: 1, indent: 16, endIndent: 16),
                _assistiveMenuItem(Icons.person, "Account Info", 'account'),
                if (canAccessSeller)
                  _assistiveMenuItem(Icons.store, "Seller Panel", 'reseller'),
                if (canAccessAdmin)
                  _assistiveMenuItem(Icons.admin_panel_settings, "Admin Panel", 'admin'),
                _assistiveMenuItem(FontAwesomeIcons.whatsapp, "Manage Sender", 'sender'),
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _assistiveMenuItem(IconData icon, String title, String page) {
    bool isActive = _activePage == page;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          splashColor: const Color(0xFF25D366).withOpacity(0.2),
          highlightColor: const Color(0xFF25D366).withOpacity(0.1),
          onTap: () => _selectFromDrawer(page),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: isActive ? BoxDecoration(
              color: const Color(0xFF102016),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF20402E), width: 1),
            ) : null,
            child: Row(
              children: [
                Icon(icon, color: isActive ? const Color(0xFF25D366) : Colors.white70, size: 18),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    title, 
                    style: TextStyle(
                      color: isActive ? Colors.white : Colors.white70, 
                      fontSize: 14, 
                      fontFamily: "ShareTechMono", 
                      fontWeight: isActive ? FontWeight.bold : FontWeight.w500,
                      letterSpacing: 1.0
                    )
                  ),
                ),
                if (isActive)
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      color: Color(0xFF25D366),
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTreeItem({required IconData icon, required String title, required String page}) {
    bool isActive = _activePage == page;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        splashColor: const Color(0xFF25D366).withOpacity(0.2),
        highlightColor: const Color(0xFF25D366).withOpacity(0.1),
        onTap: () => _selectFromDrawer(page),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 8),
          child: Row(
            children: [
              Container(
                alignment: Alignment.center,
                width: 14,
                color: const Color(0xFF0A0D0B),
                child: Icon(icon, color: isActive ? const Color(0xFF25D366) : Colors.white70, size: 16),
              ),
              const SizedBox(width: 16),
              Text(
                title,
                style: TextStyle(
                  color: isActive ? const Color(0xFF25D366) : Colors.white70,
                  fontSize: 13,
                  fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                  fontFamily: "ShareTechMono",
                  letterSpacing: 1.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFloatingNavBar() {
    return Positioned(
      bottom: 30,
      left: 15,
      right: 15,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFF0A0D0B).withOpacity(0.95),
          borderRadius: BorderRadius.circular(25),
          border: Border.all(
            color: const Color(0xFFE0E0E0).withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFE0E0E0).withOpacity(0.15),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildFloatingNavItem(Icons.home_filled, "Home", 'home'),
            _buildFloatingNavItem(FontAwesomeIcons.whatsapp, "Bug", 'bug'),
            _buildFloatingNavItem(FontAwesomeIcons.paperPlane, "Spam", 'telegram'),
            _buildFloatingNavItem(Icons.phone_android, "RAT", 'rat'),
            _buildFloatingNavItem(Icons.more_horiz, "More", 'more'),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingNavItem(IconData icon, String label, String page) {
    bool isActive = _activePage == page || (page == 'bug' && (_activePage == 'group_bug' || _activePage == 'custom_bug'));

    return GestureDetector(
      onTap: () {
        if (page == 'more') {
          setState(() {
            _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
          });
        } else if (page == 'bug') {
          _showBugOptionsSheet();
        } else {
          _selectFromDrawer(page);
        }
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: isActive
            ? BoxDecoration(
                color: const Color(0xFFE0E0E0).withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: const Color(0xFFE0E0E0).withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFFE0E0E0).withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              )
            : const BoxDecoration(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? const Color(0xFFE0E0E0) : Colors.white54,
              size: 22,
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: TextStyle(
                color: isActive ? const Color(0xFFE0E0E0) : Colors.white54,
                fontSize: 10,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                fontFamily: "ShareTechMono",
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showBugOptionsSheet() {
    final String currentRole = role.toLowerCase();
    final List<String> allowedGroupRoles = ['founder', 'moderator', 'high admin', 'owner', 'reseller', 'vip'];
    final bool canAccessGroup = allowedGroupRoles.contains(currentRole);

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _glassCard(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text("Select Bug Type", style: TextStyle(color: Colors.white, fontSize: 20, fontFamily: "Orbitron")),
                const SizedBox(height: 20),
                _glassButton(
                  icon: const Icon(Icons.person_outline),
                  label: const Text("Bug Contact"),
                  onPressed: () {
                    Navigator.pop(context);
                    _selectFromDrawer('bug');
                  },
                ),
                if (canAccessGroup) ...[
                  const SizedBox(height: 10),
                  _glassButton(
                    icon: const Icon(FontAwesomeIcons.usersSlash),
                    label: const Text("Bug Group"),
                    onPressed: () {
                      Navigator.pop(context);
                      _selectFromDrawer('group_bug');
                    },
                  ),
                ],
                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final bool isRightSide = _assistiveTouchPosition.dx > (screenSize.width / 2);
    final bool isBottomSide = _assistiveTouchPosition.dy > (screenSize.height / 2);

    return WillPopScope(
      onWillPop: () async {
        if (_activePage != 'home') {
          _selectFromDrawer('home');
          return false;
        }
        return true;
      },
      child: Scaffold(
        key: _scaffoldKey,
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Container(color: Colors.black),
            
            SafeArea(
              top: false,
              bottom: false,
              child: FadeTransition(
                opacity: _animation,
                child: _selectedPage,
              ),
            ),
            if (_activePage == 'home')
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: _buildHeader(),
              ),
            if (_isAssistiveMenuOpen)
              Positioned.fill(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      _isAssistiveMenuOpen = false;
                      _isBugToolsExpanded = false;
                    });
                  },
                  child: Container(
                    color: Colors.transparent,
                  ),
                ),
              ),
            AnimatedPositioned(
              duration: const Duration(milliseconds: 150),
              left: isRightSide ? _assistiveTouchPosition.dx - 250 : _assistiveTouchPosition.dx + 70,
              top: isBottomSide ? _assistiveTouchPosition.dy - 350 : _assistiveTouchPosition.dy,
              child: AnimatedScale(
                scale: _isAssistiveMenuOpen ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 250),
                curve: Curves.easeOutBack,
                alignment: isRightSide 
                    ? (isBottomSide ? Alignment.bottomRight : Alignment.topRight)
                    : (isBottomSide ? Alignment.bottomLeft : Alignment.topLeft),
                child: _buildAssistiveMenu(),
              ),
            ),
            Positioned(
              left: _assistiveTouchPosition.dx,
              top: _assistiveTouchPosition.dy,
              child: GestureDetector(
                onPanUpdate: (details) {
                  setState(() {
                    if (_isAssistiveMenuOpen) {
                       _isAssistiveMenuOpen = false;
                       _isBugToolsExpanded = false;
                    }

                    double newX = _assistiveTouchPosition.dx + details.delta.dx;
                    double newY = _assistiveTouchPosition.dy + details.delta.dy;
                    
                    newX = newX.clamp(0.0, screenSize.width - 60.0);
                    newY = newY.clamp(0.0, screenSize.height - 120.0);
                    
                    _assistiveTouchPosition = Offset(newX, newY);
                  });
                },
                onTap: () {
                  setState(() {
                    _isAssistiveMenuOpen = !_isAssistiveMenuOpen;
                    if(!_isAssistiveMenuOpen) _isBugToolsExpanded = false;
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: _isAssistiveMenuOpen ? const Color(0xFF102016) : Colors.black.withOpacity(0.6),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _isAssistiveMenuOpen ? const Color(0xFF25D366) : const Color(0xFFE0E0E0).withOpacity(0.4),
                      width: 1.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: _isAssistiveMenuOpen ? const Color(0xFF25D366).withOpacity(0.5) : Colors.black.withOpacity(0.5),
                        blurRadius: 12,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Image.asset(
                          'assets/images/logo.png', 
                          fit: BoxFit.contain,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            _buildFloatingNavBar(),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    _videoController?.dispose();
    _statsVideoController?.dispose(); 
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(1.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) {
    return url.endsWith(".mp4") ||
        url.endsWith(".webm") ||
        url.endsWith(".mov") ||
        url.endsWith(".mkv");
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(
          aspectRatio: _controller!.value.aspectRatio,
          child: VideoPlayer(_controller!),
        );
      } else {
        return const Center(
            child: CircularProgressIndicator(color: Color(0xFFE0E0E0)));
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.black26),
      );
    }
  }
}