// BOT TELE
module.exports = {
  BOT_TOKEN: "8859662119:AAHxj6Md97FGtH96JXSNle-rLkzAtwzsaAE", // Token bot Telegram
  OWNER_ID: "6311125849", // ID pemilik bot
  allowedGroupIds: [-4902083134], // ID grup yang diizinkan
};