import 'dart:async';
import 'dart:convert';
import 'dart:ui'; // Diperlukan untuk ImageFilter (Blur)
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage> {
  // --- State Data ---
  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  // API Status State
  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  /// --- DARK RED LUXURY THEME ---
  final Color bgBlack = const Color(0xFF0F0B0D);   // Black dengan hint wine (lebih hidup dari pure black)
  final Color bgDarkRed = const Color(0xFF1C0A0F); // Dark burgundy elegan
  final Color primaryRed = const Color(0xFF8E1B1B); // Deep maroon premium
  final Color neonRed = const Color(0xFFE53935);   // Red glow halus (tidak terlalu neon)  
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFFB0B0B0);
  
  // Card Colors
  final Color glassBg = const Color(0xFF1E1E1E).withOpacity(0.6);
  final Color glassBorder = const Color(0xFFFFFFFF).withOpacity(0.08);

  @override
  void initState() {
    super.initState();
    _fetchServerInfo();
    _startApiPingLoop();
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    super.dispose();
  }

  // --- Logic Fetch & Ping (Tidak Berubah) ---
  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse('http://dzakky.paneloffc.panelkuy.my.id:2159/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() { isLoading = false; });
      }
    } catch (e) {
      setState(() { isLoading = false; });
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _checkApiPing();
    });
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse('http://dzakky.paneloffc.panelkuy.my.id:2159/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        if (mounted) {
          setState(() {
            isApiOnline = true;
            apiPingMs = duration;
            if (duration < 200) {
              apiStatusColor = const Color(0xFF00E676); // Neon Green
            } else if (duration < 500) {
              apiStatusColor = const Color(0xFFFFC400); // Neon Amber
            } else {
              apiStatusColor = const Color(0xFFFF3D00); // Neon Orange
            }
            apiStatusText = "SYSTEM ONLINE (${duration}ms)";
          });
        }
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          isApiOnline = false;
          apiPingMs = 0;
          apiStatusColor = neonRed;
          apiStatusText = "SYSTEM OFFLINE";
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Background Gradient (Lebih mewah)
    final BoxDecoration backgroundDecoration = BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          bgBlack,
          bgDarkRed,
          bgBlack,
        ],
        stops: const [0.0, 0.5, 1.0],
      ),
    );

    if (isLoading) {
      return Scaffold(
        body: Container(
          decoration: backgroundDecoration,
          child: Center(
            child: CircularProgressIndicator(color: neonRed),
          ),
        ),
      );
    }

    final List<Map<String, String>> rulesList = [
      {
        "title": "Larangan Barter Akun",
        "desc": "Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun."
      },
      {
        "title": "Larangan Membagikan Akun",
        "desc": "Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar."
      },
      {
        "title": "Larangan Menjual Akun",
        "desc": "Member TIDAK diperbolehkan menjual akun. Penjualan akun hanya boleh dilakukan oleh role yang diizinkan secara resmi."
      },
      {
        "title": "Larangan Jual Durasi Ilegal",
        "desc": "Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan."
      },
      {
        "title": "Larangan Banting Harga",
        "desc": "Dilarang merusak atau menurunkan harga yang telah ditentukan (banting harga) di bawah ketentuan TOXIC MERCY."
      },
    ];

    return Scaffold(
      extendBodyBehindAppBar: true, // Agar background menyatu ke atas
      body: Container(
        decoration: backgroundDecoration,
        child: SafeArea(
          child: Column(
            children: [
              // --- Custom App Bar ---
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "INFO CENTER",
                      style: TextStyle(
                        color: textWhite,
                        fontSize: 22,
                        fontFamily: 'Orbitron', // Pastikan font ada atau fallback default
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                        shadows: [
                          Shadow(color: neonRed.withOpacity(0.6), blurRadius: 15, offset: const Offset(0, 0))
                        ]
                      ),
                    ),
                    _buildCompactApiStatus(),
                  ],
                ),
              ),
              
              const Divider(color: Colors.white10, height: 1),

              // --- Scrollable Content ---
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Section
                      Container(
                        margin: const EdgeInsets.only(bottom: 20),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: glassBg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: glassBorder),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.shield_outlined, color: neonRed, size: 28),
                            const SizedBox(width: 15),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "PROTOKOL PENGGUNA",
                                    style: TextStyle(
                                      color: textWhite,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      letterSpacing: 1,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    "Harap patuhi aturan demi keamanan bersama.",
                                    style: TextStyle(color: textGrey, fontSize: 12),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      ),

                      // List Peraturan
                      ...rulesList.asMap().entries.map((entry) {
                        return _buildRuleCard(entry.key + 1, entry.value);
                      }).toList(),

                      const SizedBox(height: 30),

                      // Sanksi Box (High Alert Style)
                      Stack(
                        children: [
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.6),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(color: neonRed.withOpacity(0.5), width: 1),
                              boxShadow: [
                                BoxShadow(
                                  color: neonRed.withOpacity(0.15),
                                  blurRadius: 20,
                                  spreadRadius: 2,
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Icon(Icons.dangerous_outlined, color: neonRed, size: 40),
                                const SizedBox(height: 12),
                                Text(
                                  "PELANGGARAN BERAT",
                                  style: TextStyle(
                                    color: neonRed,
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 2,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  "Jika pengguna terbukti melanggar salah satu peraturan di atas:",
                                  style: TextStyle(color: textGrey, fontSize: 13),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 12),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                  decoration: BoxDecoration(
                                    color: neonRed.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Text(
                                    "BANNED PERMANEN",
                                    style: TextStyle(
                                      color: textWhite,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 10),
                                Text(
                                  "Tanpa refund, tanpa toleransi.",
                                  style: TextStyle(
                                    color: neonRed,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                          // Decorative corners for Tech look
                          Positioned(top: 0, left: 0, child: _cornerDeco()),
                          Positioned(top: 0, right: 0, child: RotatedBox(quarterTurns: 1, child: _cornerDeco())),
                          Positioned(bottom: 0, right: 0, child: RotatedBox(quarterTurns: 2, child: _cornerDeco())),
                          Positioned(bottom: 0, left: 0, child: RotatedBox(quarterTurns: 3, child: _cornerDeco())),
                        ],
                      ),

                      const SizedBox(height: 40),

                      // Footer
                      Center(
                        child: Text(
                          "DarkVerse App Security Protocol\nVerified & Encrypted",
                          style: TextStyle(
                            color: Colors.white12,
                            fontSize: 10,
                            fontFamily: 'Monospace',
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- WIDGETS ---

  Widget _cornerDeco() {
    return Container(
      width: 15,
      height: 15,
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: neonRed, width: 2),
          left: BorderSide(color: neonRed, width: 2),
        ),
      ),
    );
  }

  Widget _buildRuleCard(int index, Map<String, String> rule) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), // Blur effect
          child: Container(
            decoration: BoxDecoration(
              color: const Color(0xFF151515).withOpacity(0.8),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.05)),
            ),
            child: IntrinsicHeight(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Side Accent Bar (Red Line)
                  Container(
                    width: 6,
                    decoration: BoxDecoration(
                      color: neonRed,
                      boxShadow: [
                        BoxShadow(
                          color: neonRed.withOpacity(0.6),
                          blurRadius: 8,
                          offset: const Offset(2, 0),
                        )
                      ]
                    ),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                rule['title']!.toUpperCase(),
                                style: TextStyle(
                                  color: textWhite,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                  letterSpacing: 0.5,
                                ),
                              ),
                              Text(
                                "#0$index",
                                style: TextStyle(
                                  color: Colors.white24,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 20,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            rule['desc']!,
                            style: TextStyle(
                              color: textGrey,
                              fontSize: 13,
                              height: 1.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCompactApiStatus() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.black45,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: apiStatusColor.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 500),
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: apiStatusColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: apiStatusColor.withOpacity(0.8),
                  blurRadius: 6,
                  spreadRadius: 1,
                )
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text(
            apiStatusText.split(' ')[0], // Ambil kata "ONLINE"/"OFFLINE" saja biar pendek
            style: TextStyle(
              color: textWhite,
              fontSize: 10,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}
